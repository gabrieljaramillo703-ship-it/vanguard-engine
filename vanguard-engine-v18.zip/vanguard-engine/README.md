# Vanguard Standard — Simulador

> **Proyecto de fans, sin afiliación con Bushiroad.** Este es un simulador de
> reglas hecho por y para fans de Cardfight!! Vanguard, sin fines comerciales.
> Los datos de cartas provienen de fuentes públicas (Cardfight Wiki en Fandom
> y el sitio oficial en.cf-vanguard.com) únicamente con fines de simulación
> — nombres, textos y diseño de las cartas son propiedad de Bushiroad Inc.
> Este repositorio (código del motor, servidor, cliente y scraper) se
> licencia bajo MIT; esa licencia no se extiende a los datos de cartas ni a
> ninguna propiedad intelectual de Bushiroad.

Simulador automático de reglas para Cardfight!! Vanguard (formato Standard),
jugable en vivo por dos personas conectadas remotamente.

## Estructura del proyecto

```
src/            Motor de reglas (fases, ataques, drive/damage check, efectos)
src/controllers Quién decide: AIController (heurística) o SocketController (jugador real)
src/effects     Sistema de efectos de carta + reglas de trigger de Standard
src/scraper     Scraper de base de datos de cartas (Fandom + sitio oficial)
data/           Mazos de prueba, habilidades de cartas escritas a mano, cards.json (generado)
server/         Servidor Socket.io — salas, sesión de partida, protocolo de decisiones
client/         Frontend React (Vite) — tablero, mano, decisiones, log en vivo
demo/           Demo de consola (IA vs IA), no necesita servidor ni cliente
```

## Cómo correr todo (necesitas 2 terminales)

**Terminal 1 — servidor:**
```
npm install
npm run server
```
Corre en `http://localhost:3001`.

**Terminal 2 — cliente web:**
```
cd client
npm install
npm run dev
```
Abre la URL que te muestre Vite (normalmente `http://localhost:5173`). Ábrela en
dos pestañas/dispositivos distintos para simular a los dos jugadores.

Si el cliente corre en una URL/dominio distinto al servidor, define
`VITE_SERVER_URL` (en `client/.env`) apuntando al servidor.

## Otros comandos útiles

| Comando | Qué hace |
|---|---|
| `npm run demo` | Corre una partida IA vs IA en consola, sin servidor ni cliente |
| `npm run test:client` | Simula 2 jugadores por WebSocket con respuestas automáticas — valida el servidor sin abrir el navegador |
| `npm run scrape` | Corre el scraper de cartas (Fandom + sitio oficial) y genera `data/cards.json` |
| `npm run inspect:fandom -- "Nombre de carta"` | Depura los campos crudos de una carta específica del wiki |

## Estado actual (ver también las notas en cada archivo)

- Motor de reglas: completo — fases, ataques, drive/damage check, guardia, triggers de Standard (sin Stand Trigger, con Over Trigger)
- Decisiones de jugador: ride, llamado, ataque y guardia son elegidas por el jugador real vía Socket.io — el motor solo automatiza matemática (poder, shield, triggers) y efectos de carta
- Scraper: funciona contra Fandom (26,870 páginas, con checkpoint/resumable); sitio oficial (`en.cf-vanguard.com`) necesita Playwright porque el listado se renderiza con JS
- Frontend: tablero funcional con círculos de vanguard/rear-guard, mano privada, overlay de decisiones y log en vivo — usa mazos de prueba sintéticos por defecto (todavía no hay UI de selección de mazo desde `cards.json`)

## Pendiente / próximos pasos naturales

- UI de construcción de mazo real (elegir cartas de `data/cards.json`)
- Ataques a rear-guards del rival (hoy todo ataque va al vanguard)
- Más habilidades de carta escritas a mano en `data/cardEffects.js`
- Terminar de correr el scraper completo y validar la calidad de `cards.json`
