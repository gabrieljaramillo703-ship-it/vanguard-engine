import React, { useEffect, useRef, useState } from "react";
import { io } from "socket.io-client";
import Lobby from "./components/Lobby.jsx";
import DeckBuilder from "./components/DeckBuilder.jsx";
import PlayerField from "./components/PlayerField.jsx";
import Hand from "./components/Hand.jsx";
import LogFeed from "./components/LogFeed.jsx";
import DecisionOverlay from "./components/DecisionOverlay.jsx";

const SERVER_URL = import.meta.env.VITE_SERVER_URL || "http://localhost:3001";

export default function App() {
  const socketRef = useRef(null);
  const [screen, setScreen] = useState("lobby"); // lobby | waiting | playing | over
  const [roomId, setRoomId] = useState(null);
  const [seatIndex, setSeatIndex] = useState(null);
  const [boardState, setBoardState] = useState(null);
  const [hand, setHand] = useState([]);
  const [logLines, setLogLines] = useState([]);
  const [pendingDecision, setPendingDecision] = useState(null);
  const [winner, setWinner] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);
  const [deckSubmitted, setDeckSubmitted] = useState(false);

  useEffect(() => {
    const socket = io(SERVER_URL);
    socketRef.current = socket;

    socket.on("errorMessage", ({ message }) => {
      setErrorMsg(message);
      setDeckSubmitted(false); // let the player retry (e.g. deck was rejected as invalid)
    });

    socket.on("roomJoined", ({ seatIndex }) => {
      setSeatIndex(seatIndex);
      setScreen("waiting");
    });

    socket.on("matchStarted", () => {
      setScreen("playing");
      setWinner(null);
    });

    socket.on("stateUpdate", (snapshot) => setBoardState(snapshot));

    socket.on("yourHand", ({ hand }) => setHand(hand));

    socket.on("matchLog", ({ message }) => {
      setLogLines((prev) => [...prev.slice(-99), message]);
    });

    socket.on("decisionRequest", (decision) => setPendingDecision(decision));

    socket.on("matchOver", ({ winner }) => {
      setWinner(winner);
      setScreen("over");
    });

    return () => socket.disconnect();
  }, []);

  function createRoom(name, code) {
    setRoomId(code);
    socketRef.current.emit("createRoom", { roomId: code });
    // Deck submission happens once we know we've joined (see waiting screen button).
    socketRef.current._pendingName = name;
  }

  function joinRoom(name, code) {
    setRoomId(code);
    socketRef.current.emit("joinRoom", { roomId: code });
    socketRef.current._pendingName = name;
  }

  function submitDeck(deckChoice) {
    // deckChoice is either { cardIds, startingVanguardId } from DeckBuilder,
    // or undefined for the synthetic fallback deck (no cardIds -> server builds one).
    socketRef.current.emit("submitDeck", {
      roomId,
      name: socketRef.current._pendingName,
      ...(deckChoice || {}),
    });
    setDeckSubmitted(true);
  }

  function answerDecision(choice) {
    if (!pendingDecision) return;
    socketRef.current.emit("decisionResponse", { requestId: pendingDecision.requestId, choice });
    setPendingDecision(null);
  }

  if (screen === "lobby") {
    return (
      <>
        <Lobby onCreate={createRoom} onJoin={joinRoom} />
        {errorMsg && <ErrorToast message={errorMsg} onClose={() => setErrorMsg(null)} />}
      </>
    );
  }

  if (screen === "waiting") {
    if (deckSubmitted) {
      return (
        <div className="lobby">
          <h1>Sala {roomId}</h1>
          <p className="subtitle">Mazo enviado. Esperando a que tu rival termine el suyo…</p>
          {errorMsg && <ErrorToast message={errorMsg} onClose={() => setErrorMsg(null)} />}
        </div>
      );
    }
    return (
      <>
        <div className="lobby" style={{ paddingTop: "1rem" }}>
          <p className="subtitle" style={{ marginTop: 0 }}>Sala {roomId} — comparte este código con tu rival</p>
        </div>
        <DeckBuilder
          onSubmit={(deckChoice) => submitDeck(deckChoice)}
          onUseFallbackDeck={() => submitDeck(undefined)}
        />
        {errorMsg && <ErrorToast message={errorMsg} onClose={() => setErrorMsg(null)} />}
      </>
    );
  }

  if (!boardState) {
    return (
      <div className="lobby">
        <p>Cargando partida…</p>
      </div>
    );
  }

  const me = boardState.players[seatIndex];
  const opponent = boardState.players[1 - seatIndex];

  return (
    <div className="board-screen">
      <div className="board">
        <PlayerField player={opponent} isTurnPlayer={boardState.turnPlayer === opponent.name} flipped={false} />
        <PlayerField player={me} isTurnPlayer={boardState.turnPlayer === me.name} flipped />
      </div>
      <Hand hand={hand} />
      <LogFeed lines={logLines} />

      {pendingDecision && <DecisionOverlay decision={pendingDecision} onAnswer={answerDecision} />}

      {screen === "over" && (
        <div className="match-over-banner">
          <h1>{winner === me.name ? "¡Ganaste!" : `Ganó ${winner}`}</h1>
          <button onClick={() => window.location.reload()}>Volver al lobby</button>
        </div>
      )}

      {errorMsg && <ErrorToast message={errorMsg} onClose={() => setErrorMsg(null)} />}
    </div>
  );
}

function ErrorToast({ message, onClose }) {
  return (
    <div
      style={{
        position: "fixed",
        bottom: 16,
        right: 16,
        background: "var(--crimson)",
        padding: "0.75rem 1rem",
        borderRadius: 8,
        cursor: "pointer",
      }}
      onClick={onClose}
    >
      {message}
    </div>
  );
}
