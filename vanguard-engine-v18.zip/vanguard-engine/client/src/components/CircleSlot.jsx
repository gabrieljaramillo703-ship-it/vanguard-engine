import React from "react";

const SLOT_LABELS = {
  backLeft: "BL",
  frontLeft: "FL",
  frontCenter: "FC",
  frontRight: "FR",
  backRight: "BR",
};

export default function CircleSlot({ card, isVanguard, slotKey }) {
  const classes = ["circle-slot"];
  if (isVanguard) classes.push("vanguard");
  if (card) classes.push("occupied");
  if (card?.isRested) classes.push("rested");

  return (
    <div className={classes.join(" ")}>
      {card ? (
        <>
          <span>{card.name}</span>
          <span className="card-power">{card.power.toLocaleString()}</span>
        </>
      ) : (
        <span style={{ opacity: 0.4 }}>{isVanguard ? "VG" : SLOT_LABELS[slotKey]}</span>
      )}
    </div>
  );
}
