import React, { useState } from "react";

const TITLES = {
  chooseRide: "Fase de Ride",
  chooseStride: "¡Stride disponible!",
  chooseNextCall: "Fase Principal",
  chooseNextAttacker: "Fase de Batalla",
  chooseGuardians: "¡Te están atacando!",
};

const HINTS = {
  chooseRide: "Vas a montar esta carta del Ride Deck. Elige qué carta de tu mano descartas como costo, o pasa.",
  chooseStride: "Elige tu unidad de Stride y qué cartas descartas (la suma de sus grados debe ser 3 o más).",
  chooseNextCall: "Elige una carta para llamar y en qué círculo, o termina de llamar.",
  chooseNextAttacker: "Elige con qué unidad atacar, o termina la fase de batalla.",
  chooseGuardians: "Elige guardianes de tu mano (puedes no guardar ninguno).",
};

export default function DecisionOverlay({ decision, onAnswer }) {
  const { type, payload } = decision;
  const [selectedCardIndex, setSelectedCardIndex] = useState(null);
  const [selectedGuardians, setSelectedGuardians] = useState([]);
  const [selectedStrideIndex, setSelectedStrideIndex] = useState(null);
  const [selectedDiscards, setSelectedDiscards] = useState([]);

  if (type === "chooseRide") {
    return (
      <div className="decision-overlay">
        <div className="decision-panel">
          <h2>{TITLES[type]}</h2>
          <p className="hint">
            Próximo ride: <strong>{payload.nextRideCard.name}</strong> (Grado {payload.nextRideCard.grade}). {HINTS[type]}
          </p>
          <div className="decision-options">
            {payload.hand.map((c, i) => (
              <div key={i} className="decision-option" onClick={() => onAnswer({ discardCardIndex: i })}>
                <span>{c.name}</span>
                <span>G{c.grade} · {c.power.toLocaleString()}</span>
              </div>
            ))}
          </div>
          <div style={{ marginTop: "1rem" }}>
            <button className="secondary" onClick={() => onAnswer(null)}>
              No montar esta carta
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (type === "chooseStride") {
    const toggleDiscard = (i) => {
      setSelectedDiscards((prev) => (prev.includes(i) ? prev.filter((x) => x !== i) : [...prev, i]));
    };
    const gradeSum = selectedDiscards.reduce((sum, i) => sum + payload.hand[i].grade, 0);
    const canConfirm = selectedStrideIndex != null && gradeSum >= 3;

    return (
      <div className="decision-overlay">
        <div className="decision-panel">
          <h2>{TITLES[type]}</h2>
          <p className="hint">{HINTS[type]} Suma actual: {gradeSum}/3.</p>
          <p className="hint" style={{ marginBottom: "0.3rem" }}>Unidad de Stride:</p>
          <div className="decision-options">
            {payload.candidates.map((c, i) => (
              <div
                key={i}
                className={`decision-option ${selectedStrideIndex === i ? "chosen" : ""}`}
                onClick={() => setSelectedStrideIndex(i)}
              >
                <span>{c.name}</span>
                <span>{c.power.toLocaleString()}</span>
              </div>
            ))}
          </div>
          <p className="hint" style={{ marginTop: "0.75rem", marginBottom: "0.3rem" }}>Descartar (costo):</p>
          <div className="decision-options">
            {payload.hand.map((c, i) => (
              <div
                key={i}
                className={`decision-option ${selectedDiscards.includes(i) ? "chosen" : ""}`}
                onClick={() => toggleDiscard(i)}
              >
                <span>{c.name}</span>
                <span>G{c.grade}</span>
              </div>
            ))}
          </div>
          <div style={{ marginTop: "1rem", display: "flex", gap: "0.5rem" }}>
            <button
              disabled={!canConfirm}
              onClick={() => onAnswer({ strideIndex: selectedStrideIndex, discardIndices: selectedDiscards })}
            >
              Confirmar Stride
            </button>
            <button className="secondary" onClick={() => onAnswer(null)}>
              No hacer Stride
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (type === "chooseGuardians") {
    const toggle = (i) => {
      setSelectedGuardians((prev) => (prev.includes(i) ? prev.filter((x) => x !== i) : [...prev, i]));
    };
    const shieldTotal = selectedGuardians.reduce((sum, i) => sum + payload.candidates[i].shield, 0);

    return (
      <div className="decision-overlay">
        <div className="decision-panel">
          <h2>{TITLES[type]}</h2>
          <p className="hint">
            {payload.attackInfo.attackerName} ataca con {payload.attackInfo.attackPower.toLocaleString()} de poder
            contra tu vanguard ({payload.attackInfo.defendingVanguardPower.toLocaleString()}). Shield elegido:{" "}
            {shieldTotal.toLocaleString()}.
          </p>
          <div className="decision-options">
            {payload.candidates.map((c, i) => (
              <div
                key={i}
                className={`decision-option ${selectedGuardians.includes(i) ? "chosen" : ""}`}
                onClick={() => toggle(i)}
              >
                <span>{c.name}</span>
                <span>Shield {c.shield.toLocaleString()}</span>
              </div>
            ))}
          </div>
          <div style={{ marginTop: "1rem", display: "flex", gap: "0.5rem" }}>
            <button onClick={() => onAnswer(selectedGuardians)}>
              {selectedGuardians.length > 0 ? "Confirmar guardia" : "No guardar (recibir el golpe)"}
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (type === "chooseNextCall") {
    const selected = selectedCardIndex != null ? payload.candidates[selectedCardIndex] : null;
    return (
      <div className="decision-overlay">
        <div className="decision-panel">
          <h2>{TITLES[type]}</h2>
          <p className="hint">{HINTS[type]}</p>
          <div className="decision-options">
            {payload.candidates.map((c, i) => (
              <div
                key={i}
                className={`decision-option ${selectedCardIndex === i ? "chosen" : ""}`}
                onClick={() => setSelectedCardIndex(i)}
              >
                <span>{c.name}</span>
                <span>G{c.grade} · {c.power.toLocaleString()}</span>
              </div>
            ))}
          </div>
          {selected && (
            <>
              <p className="hint" style={{ marginTop: "0.75rem" }}>
                ¿En qué círculo colocas a {selected.name}?
              </p>
              <div className="decision-options">
                {payload.openSlots.map((slot) => (
                  <div
                    key={slot}
                    className="decision-option"
                    onClick={() => onAnswer({ cardIndex: selectedCardIndex, slot })}
                  >
                    <span>{slot}</span>
                  </div>
                ))}
              </div>
            </>
          )}
          <div style={{ marginTop: "1rem" }}>
            <button className="secondary" onClick={() => onAnswer(null)}>
              Terminar de llamar
            </button>
          </div>
        </div>
      </div>
    );
  }

  // chooseNextAttacker — simple single-select + skip
  return (
    <div className="decision-overlay">
      <div className="decision-panel">
        <h2>{TITLES[type]}</h2>
        <p className="hint">{HINTS[type]}</p>
        <div className="decision-options">
          {payload.candidates.map((c, i) => (
            <div key={i} className="decision-option" onClick={() => onAnswer(i)}>
              <span>{c.name}</span>
              <span>
                G{c.grade} · {c.power.toLocaleString()}
                {c.slot ? ` · ${c.slot}` : ""}
              </span>
            </div>
          ))}
        </div>
        <div style={{ marginTop: "1rem" }}>
          <button className="secondary" onClick={() => onAnswer(null)}>
            Terminar de atacar
          </button>
        </div>
      </div>
    </div>
  );
}
