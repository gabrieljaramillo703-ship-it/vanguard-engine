import React, { useEffect, useState } from "react";

const SERVER_URL = import.meta.env.VITE_SERVER_URL || "http://localhost:3001";
const MAIN_DECK_SIZE = 50;
const RIDE_GRADES = [0, 1, 2, 3];

export default function DeckBuilder({ onSubmit, onUseFallbackDeck }) {
  const [dbStatus, setDbStatus] = useState(null);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);

  const [rideDeck, setRideDeck] = useState({ 0: null, 1: null, 2: null, 3: null });
  const [gZone, setGZone] = useState([]); // array of cards, max 8
  const [mainDeck, setMainDeck] = useState({}); // id -> { card, count }

  useEffect(() => {
    fetch(`${SERVER_URL}/api/cards/status`)
      .then((r) => r.json())
      .then(setDbStatus)
      .catch(() => setDbStatus({ available: false, count: 0 }));
  }, []);

  useEffect(() => {
    if (!dbStatus?.available) return;
    setLoading(true);
    const handle = setTimeout(() => {
      fetch(`${SERVER_URL}/api/cards?q=${encodeURIComponent(query)}&limit=30`)
        .then((r) => r.json())
        .then((data) => setResults(data.results))
        .finally(() => setLoading(false));
    }, 250);
    return () => clearTimeout(handle);
  }, [query, dbStatus]);

  const mainDeckCount = Object.values(mainDeck).reduce((sum, e) => sum + e.count, 0);

  function mainDeckCopies(id) {
    return mainDeck[id]?.count || 0;
  }

  function gZoneCopies(id) {
    return gZone.filter((c) => c.id === id).length;
  }

  function addToRideDeck(card) {
    if (card.grade > 3 || card.cardType !== "unit") return;
    if (rideDeck[card.grade]) return; // slot already filled
    setRideDeck((prev) => ({ ...prev, [card.grade]: card }));
  }

  function removeFromRideDeck(grade) {
    setRideDeck((prev) => ({ ...prev, [grade]: null }));
  }

  function addToGZone(card) {
    if (!card.isStrideUnit || gZone.length >= 8) return;
    if (gZoneCopies(card.id) >= 4) return;
    setGZone((prev) => [...prev, card]);
  }

  function removeFromGZone(index) {
    setGZone((prev) => prev.filter((_, i) => i !== index));
  }

  function addToMainDeck(card) {
    if (mainDeckCount >= MAIN_DECK_SIZE) return;
    if (mainDeckCopies(card.id) >= 4) return;
    setMainDeck((prev) => {
      const existing = prev[card.id];
      return { ...prev, [card.id]: { card, count: (existing?.count || 0) + 1 } };
    });
  }

  function removeFromMainDeck(id) {
    setMainDeck((prev) => {
      const existing = prev[id];
      if (!existing) return prev;
      if (existing.count <= 1) {
        const next = { ...prev };
        delete next[id];
        return next;
      }
      return { ...prev, [id]: { ...existing, count: existing.count - 1 } };
    });
  }

  const rideDeckComplete = RIDE_GRADES.every((g) => rideDeck[g]);
  const canConfirm = rideDeckComplete && mainDeckCount === MAIN_DECK_SIZE;

  function confirm() {
    const mainDeckCardIds = Object.values(mainDeck).flatMap((e) => Array(e.count).fill(e.card.id));
    const rideDeckCardIds = RIDE_GRADES.map((g) => rideDeck[g].id);
    const gZoneCardIds = gZone.map((c) => c.id);
    onSubmit({ mainDeckCardIds, rideDeckCardIds, gZoneCardIds });
  }

  if (dbStatus === null) {
    return (
      <div className="lobby">
        <p>Consultando base de datos de cartas…</p>
      </div>
    );
  }

  if (!dbStatus.available) {
    return (
      <div className="lobby">
        <h1>Base de datos aún no lista</h1>
        <p className="subtitle">
          Todavía no hay cartas cargadas (corre <code>npm run scrape</code> en el servidor). Puedes jugar mientras
          tanto con un mazo de prueba sintético.
        </p>
        <button onClick={onUseFallbackDeck}>Usar mazo de prueba</button>
      </div>
    );
  }

  return (
    <div className="lobby" style={{ maxWidth: 1000, width: "100%" }}>
      <h1>Construye tu mazo</h1>
      <p className="subtitle">
        Ride Deck {RIDE_GRADES.filter((g) => rideDeck[g]).length}/4 · G Zone {gZone.length}/8 · Main Deck{" "}
        {mainDeckCount}/{MAIN_DECK_SIZE} · {dbStatus.count.toLocaleString()} cartas disponibles
      </p>

      <input
        type="text"
        placeholder="Buscar carta por nombre…"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        style={{ width: "100%", marginBottom: "1rem" }}
      />

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem", width: "100%" }}>
        <div>
          <h3 style={{ fontFamily: "var(--font-display)", color: "var(--gold)" }}>Resultados</h3>
          <div className="decision-options" style={{ maxHeight: 420, overflowY: "auto" }}>
            {loading && <p style={{ color: "var(--text-dim)" }}>Buscando…</p>}
            {!loading &&
              results.map((card) => (
                <div key={card.id} className="decision-option" style={{ flexDirection: "column", alignItems: "stretch", gap: "0.4rem" }}>
                  <div style={{ display: "flex", justifyContent: "space-between" }}>
                    <span>{card.name}</span>
                    <span>
                      G{card.grade} · {card.power?.toLocaleString() ?? "—"}
                      {card.isStrideUnit ? " · Stride" : ""}
                    </span>
                  </div>
                  <div style={{ display: "flex", gap: "0.4rem" }}>
                    {card.isStrideUnit ? (
                      <button className="secondary" onClick={() => addToGZone(card)} disabled={gZone.length >= 8}>
                        + G Zone
                      </button>
                    ) : (
                      <>
                        <button
                          className="secondary"
                          onClick={() => addToRideDeck(card)}
                          disabled={card.grade > 3 || !!rideDeck[card.grade]}
                        >
                          + Ride Deck (G{card.grade})
                        </button>
                        <button className="secondary" onClick={() => addToMainDeck(card)} disabled={mainDeckCount >= MAIN_DECK_SIZE}>
                          + Main Deck
                        </button>
                      </>
                    )}
                  </div>
                </div>
              ))}
          </div>
        </div>

        <div>
          <h3 style={{ fontFamily: "var(--font-display)", color: "var(--gold)" }}>Ride Deck (Grado 0-3)</h3>
          <div className="decision-options" style={{ marginBottom: "1rem" }}>
            {RIDE_GRADES.map((g) => (
              <div key={g} className="decision-option" onClick={() => rideDeck[g] && removeFromRideDeck(g)}>
                <span>Grado {g}</span>
                <span>{rideDeck[g] ? rideDeck[g].name : "— vacío —"}</span>
              </div>
            ))}
          </div>

          <h3 style={{ fontFamily: "var(--font-display)", color: "var(--gold)" }}>G Zone (Stride)</h3>
          <div className="decision-options" style={{ marginBottom: "1rem", maxHeight: 140, overflowY: "auto" }}>
            {gZone.length === 0 && <p style={{ color: "var(--text-dim)", fontSize: "0.85rem" }}>Vacío (opcional)</p>}
            {gZone.map((card, i) => (
              <div key={i} className="decision-option" onClick={() => removeFromGZone(i)}>
                <span>{card.name}</span>
                <span style={{ color: "var(--crimson-bright)" }}>Quitar</span>
              </div>
            ))}
          </div>

          <h3 style={{ fontFamily: "var(--font-display)", color: "var(--gold)" }}>Main Deck</h3>
          <div className="decision-options" style={{ maxHeight: 180, overflowY: "auto" }}>
            {Object.values(mainDeck).map(({ card, count }) => (
              <div key={card.id} className="decision-option" onClick={() => removeFromMainDeck(card.id)}>
                <span>
                  {card.name} ×{count}
                </span>
                <span style={{ color: "var(--crimson-bright)" }}>Quitar</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <button style={{ marginTop: "1rem" }} disabled={!canConfirm} onClick={confirm}>
        Confirmar mazo {!rideDeckComplete ? "(falta Ride Deck)" : `(${mainDeckCount}/${MAIN_DECK_SIZE})`}
      </button>
    </div>
  );
}
