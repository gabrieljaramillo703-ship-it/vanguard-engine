import React from "react";

export default function Hand({ hand }) {
  return (
    <div className="hand-bar">
      {hand.length === 0 && <span style={{ color: "var(--text-dim)", fontSize: "0.85rem" }}>Sin cartas en mano</span>}
      {hand.map((card, i) => (
        <div className="hand-card" key={`${card.id}-${i}`}>
          <span className="name">{card.name}</span>
          <span className="stats">
            G{card.grade} · {card.power.toLocaleString()}
            {card.shield > 0 ? ` · Shield ${card.shield.toLocaleString()}` : ""}
          </span>
        </div>
      ))}
    </div>
  );
}
