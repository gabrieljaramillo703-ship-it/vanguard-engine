import React, { useState } from "react";

function randomRoomCode() {
  return Math.random().toString(36).slice(2, 7).toUpperCase();
}

export default function Lobby({ onCreate, onJoin }) {
  const [name, setName] = useState("");
  const [roomCode, setRoomCode] = useState("");

  return (
    <div className="lobby">
      <h1>Vanguard — Standard</h1>
      <p className="subtitle">Simulador automático de reglas — partidas reales, 2 jugadores</p>
      <div className="lobby-form">
        <input
          type="text"
          placeholder="Tu nombre"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          type="text"
          placeholder="Código de sala (déjalo vacío para crear una nueva)"
          value={roomCode}
          onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
        />
        <button
          onClick={() => onCreate(name || "Jugador", roomCode || randomRoomCode())}
          disabled={!name}
        >
          Crear sala
        </button>
        <button
          className="secondary"
          onClick={() => onJoin(name || "Jugador", roomCode)}
          disabled={!name || !roomCode}
        >
          Unirse a sala
        </button>
      </div>
    </div>
  );
}
