import React, { useEffect, useRef } from "react";

export default function LogFeed({ lines }) {
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [lines.length]);

  return (
    <div className="log-feed">
      {lines.map((line, i) => (
        <div key={i} className={`log-line ${/TRIGGER|HITS/.test(line) ? "highlight" : ""}`}>
          {line}
        </div>
      ))}
      <div ref={bottomRef} />
    </div>
  );
}
