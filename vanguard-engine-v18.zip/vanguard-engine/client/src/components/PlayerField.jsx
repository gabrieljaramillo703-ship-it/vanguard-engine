import React from "react";
import CircleSlot from "./CircleSlot.jsx";

const SLOT_ORDER = ["backLeft", "frontLeft", "frontCenter", "frontRight", "backRight"];

export default function PlayerField({ player, isTurnPlayer, flipped }) {
  const zones = (
    <div className="field-zones">
      {!flipped && (
        <div className="rear-guard-row">
          {SLOT_ORDER.map((slot) => (
            <CircleSlot key={slot} slotKey={slot} card={player.rearGuard[slot]} />
          ))}
        </div>
      )}
      <CircleSlot isVanguard card={player.vanguard} />
      {flipped && (
        <div className="rear-guard-row">
          {SLOT_ORDER.map((slot) => (
            <CircleSlot key={slot} slotKey={slot} card={player.rearGuard[slot]} />
          ))}
        </div>
      )}
    </div>
  );

  const meta = (
    <div className="player-meta">
      <span className="player-name">{player.name}</span>
      <div className="damage-dots">
        {Array.from({ length: 6 }).map((_, i) => (
          <span key={i} className={`damage-dot ${i < player.damage ? "filled" : ""}`} />
        ))}
      </div>
      <span className="meta-row">Mazo: {player.deckCount} · Mano: {player.handSize}</span>
    </div>
  );

  return (
    <div className={`player-field ${isTurnPlayer ? "turn-active" : ""}`}>
      {flipped ? (
        <>
          {meta}
          {zones}
        </>
      ) : (
        <>
          {zones}
          {meta}
        </>
      )}
    </div>
  );
}
