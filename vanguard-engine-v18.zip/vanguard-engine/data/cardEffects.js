/**
 * cardEffects.js
 *
 * Hand-authored skills for specific, named cards — matched by card id. This
 * is NOT generated from scraped skill text (natural-language card text is
 * too inconsistent to parse reliably into logic); each entry here is
 * someone reading the real card and writing what it does using the hooks
 * in src/effects/EffectHooks.js.
 *
 * Usage: after loading cards (from data/cards.json or the test deck
 * builder), look up each card's id in EFFECTS_BY_ID and attach the entry to
 * card.effects before the deck is used in a game. See attachEffects() below.
 *
 * Two real examples included to establish the pattern:
 *   - Blaster Blade (BT01/003): "AUTO: When this unit is placed on (VC),
 *     choose 1 of your opponent's rear-guards, and retire it." [Royal Paladin]
 *   - Battle Sister, Chocolat (BT01/032): "AUTO: When this unit attacks a
 *     vanguard, if you have a heart card with 'Battle Sister' in its card
 *     name, this unit gets Power+3000 until end of that battle." [Genesis]
 *     (Simplified here to "always" since heart-card clan-name checks aren't
 *     modeled yet — flagged with a TODO.)
 */

const EFFECTS_BY_ID = {
  "BT01/003": [
    {
      hook: "onPlaceVC",
      name: "Blaster Blade: retire a rear-guard on ride",
      handler: (ctx) => {
        const targets = ctx.opponent.allRearGuards();
        if (targets.length === 0) {
          ctx.log(`${ctx.source.name}'s skill has no legal target (opponent has no rear-guards).`);
          return;
        }
        // Automated choice: retire the highest-power rear-guard (removes the
        // opponent's best attacker/booster). A real AI/player-choice layer
        // can replace this heuristic later without touching the hook wiring.
        const target = targets.sort((a, b) => b.power - a.power)[0];
        const slot = Object.entries(ctx.opponent.rearGuard).find(([, c]) => c === target)?.[0];
        if (slot) ctx.opponent.rearGuard[slot] = null;
        ctx.opponent.dropZone.push(target);
        ctx.log(`${ctx.source.name}'s skill retires ${target.name}.`);
      },
    },
  ],

  "BT01/032": [
    {
      hook: "onAttack",
      name: "Battle Sister, Chocolat: Power+3000 on attack",
      handler: (ctx) => {
        // TODO: real card requires a "Battle Sister" heart card — heart-card
        // tracking (soul contents by clan) isn't modeled yet, so this
        // simplified version always applies. Revisit once soul/heart
        // tracking exists.
        ctx.source.powerBonus += 3000;
        ctx.log(`${ctx.source.name}'s skill: Power+3000 for this battle.`);
      },
    },
  ],
};

/** Attaches any hand-authored effects to a card, matched by its id. Safe to call on every card — cards with no entry are untouched. */
function attachEffects(card) {
  const entries = EFFECTS_BY_ID[card.id];
  if (entries) card.effects.push(...entries);
  return card;
}

module.exports = { EFFECTS_BY_ID, attachEffects };
