const Card = require("../src/Card");

/**
 * Builds a Standard-format-legal-SHAPED test deck (real card data arrives
 * via the scraper — see data/cards.json):
 *   - Ride Deck: 4 cards, Grade 0/1/2/3, guaranteed ride line (separate zone)
 *   - G Zone: 4 Grade 4 Stride units (max is 8; 4 is enough to exercise the mechanic)
 *   - Main Deck: 50 cards, fully separate from the Ride Deck — 16 triggers
 *     (Standard mix: no Stand, max 4 Heal, max 1 Over) + 34 units spread
 *     across grades 0-3
 */
function buildTestDeck(prefix) {
  let n = 1;
  const nextId = () => `${prefix}-${String(n++).padStart(3, "0")}`;

  const makeUnit = (grade, power, shield, extra = {}) =>
    new Card({ id: nextId(), name: `${prefix} G${grade} Unit ${n}`, grade, power, shield, ...extra });

  const makeTrigger = (triggerType, power = 5000) =>
    new Card({ id: nextId(), name: `${prefix} Trigger (${triggerType})`, grade: 0, power, shield: 10000, triggerType });

  const makeStrideUnit = () =>
    new Card({ id: nextId(), name: `${prefix} Stride Unit ${n}`, grade: 4, power: 15000, isStrideUnit: true });

  // ---- Ride Deck (4 cards, Grade 0 -> 3) — separate zone from Main Deck ----
  const rideDeck = [
    new Card({ id: nextId(), name: `${prefix} Starter`, grade: 0, power: 6000, shield: 0, critical: 1 }),
    makeUnit(1, 8000, 5000),
    makeUnit(2, 9000, 0),
    makeUnit(3, 10000, 0, { critical: 2 }),
  ];

  // ---- G Zone (4 Stride units) — separate zone from Main Deck ----
  const gZone = [makeStrideUnit(), makeStrideUnit(), makeStrideUnit(), makeStrideUnit()];

  // ---- Main Deck (50 cards, fully separate from the Ride Deck) ----
  const mainDeckCards = [];
  // 16 triggers: 4 critical, 4 draw, 4 front, 3 heal, 1 over
  ["critical", "draw", "front"].forEach((t) => {
    for (let i = 0; i < 4; i++) mainDeckCards.push(makeTrigger(t));
  });
  for (let i = 0; i < 3; i++) mainDeckCards.push(makeTrigger("heal"));
  mainDeckCards.push(makeTrigger("over"));
  // 34 units: 8 grade 0, 10 grade 1, 8 grade 2, 8 grade 3
  for (let i = 0; i < 8; i++) mainDeckCards.push(makeUnit(0, 7000, 10000));
  for (let i = 0; i < 10; i++) mainDeckCards.push(makeUnit(1, 8000, 5000));
  for (let i = 0; i < 8; i++) mainDeckCards.push(makeUnit(2, 9000, 0));
  for (let i = 0; i < 8; i++) mainDeckCards.push(makeUnit(3, 10000, 0, { critical: 2 }));

  return { mainDeckCards, rideDeck, gZone };
}

module.exports = { buildTestDeck };
