const Player = require("../src/Player");
const Engine = require("../src/Engine");
const { buildTestDeck } = require("../data/testCards");

async function main() {
  const deck1 = buildTestDeck("P1");
  const deck2 = buildTestDeck("P2");

  const player1 = new Player("Gabriel", deck1.mainDeckCards, deck1.rideDeck, deck1.gZone);
  const player2 = new Player("CPU", deck2.mainDeckCards, deck2.rideDeck, deck2.gZone);

  player1.drawCards(5);
  player2.drawCards(5);

  // No controllers passed -> both sides default to AIController, so this
  // demo still runs unattended end-to-end. Pass a SocketController for a
  // real player instead (see server/GameSession.js).
  const engine = new Engine(player1, player2, { verbose: true });
  const finalState = await engine.playGame(40);

  console.log("\n--- FINAL STATE ---");
  finalState.players.forEach((p) => {
    console.log(
      `${p.name}: damage ${p.damageCount}/6, hand ${p.hand.length}, deck ${p.deck.count}, vanguard ${p.vanguardCircle.name} (G${p.vanguardCircle.grade})`
    );
  });
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
