const Player = require("../src/Player");
const Engine = require("../src/Engine");
const SocketController = require("../src/controllers/SocketController");
const { loadDeck } = require("./loadDeck");

/**
 * GameSession.js
 *
 * A real, playable match between two connected players. Each player's
 * SocketController sends decisionRequest events to THEIR OWN socket only
 * (ride/call/attack/guard) and waits for their decisionResponse — this is
 * what makes it an actual game instead of a replay. Both players still
 * receive every stateUpdate/matchLog broadcast, so each can see the full
 * board (their own zones and their opponent's), the same way two people
 * would see the same physical table.
 */
class GameSession {
  constructor(io, roomId, seatSockets, playerConfigs) {
    this.io = io;
    this.roomId = roomId;

    const [p1Config, p2Config] = playerConfigs;
    const deck1 = loadDeck({ ...p1Config, namePrefix: "P1" });
    const deck2 = loadDeck({ ...p2Config, namePrefix: "P2" });

    const player1 = new Player(p1Config.name || "Player 1", deck1.mainDeckCards, deck1.rideDeck, deck1.gZone);
    const player2 = new Player(p2Config.name || "Player 2", deck2.mainDeckCards, deck2.rideDeck, deck2.gZone);
    player1.drawCards(5);
    player2.drawCards(5);

    const controller1 = new SocketController(seatSockets[0]);
    const controller2 = new SocketController(seatSockets[1]);
    this.seatSockets = seatSockets;

    this.engine = new Engine(player1, player2, { controller1, controller2, verbose: false });

    // Every engine log line gets broadcast to both players in the room.
    const originalNote = this.engine.state.note.bind(this.engine.state);
    this.engine.state.note = (message) => {
      originalNote(message);
      this.io.to(this.roomId).emit("matchLog", { message });
      this.broadcastState(); // keep both clients' boards in sync as things happen, not just once per phase
      this.sendPrivateHands(); // hand contents are private — never part of the shared broadcast
    };
  }

  /** Sends each player's own hand to their own socket only — never broadcast, never sent to the opponent. */
  sendPrivateHands() {
    this.engine.state.players.forEach((p, i) => {
      this.seatSockets[i].emit("yourHand", { hand: p.hand.map(cardSummary) });
    });
  }

  async run() {
    this.io.to(this.roomId).emit("matchStarted", {
      players: this.engine.state.players.map((p) => ({ name: p.name })),
    });
    this.broadcastState();
    this.sendPrivateHands();

    await this.engine.playGame(100);

    this.io.to(this.roomId).emit("matchOver", {
      winner: this.engine.state.winner ? this.engine.state.winner.name : null,
    });
  }

  /** Sends a compact snapshot of both fields — enough for a client to render a board. */
  broadcastState() {
    const snapshot = {
      turnNumber: this.engine.state.turnNumber,
      phase: this.engine.state.currentPhase,
      turnPlayer: this.engine.state.turnPlayer.name,
      winner: this.engine.state.winner ? this.engine.state.winner.name : null,
      players: this.engine.state.players.map((p) => ({
        name: p.name,
        damage: p.damageCount,
        handSize: p.hand.length,
        deckCount: p.deck.count,
        vanguard: cardSummary(p.vanguardCircle),
        rearGuard: Object.fromEntries(Object.entries(p.rearGuard).map(([slot, card]) => [slot, cardSummary(card)])),
      })),
    };
    this.io.to(this.roomId).emit("stateUpdate", snapshot);
  }
}

function cardSummary(card) {
  if (!card) return null;
  return { name: card.name, grade: card.grade, power: card.totalPower, isRested: card.isRested };
}

module.exports = GameSession;
