/**
 * RoomManager.js
 *
 * A room = up to 2 players who will watch/play the same match together.
 * Deliberately simple (in-memory Map) — fine for a single server process.
 * If this ever needs to run across multiple server instances, room state
 * would move to something shared (Redis, etc.) instead of process memory,
 * but nothing about the Socket.io event contract in index.js would change.
 */
class RoomManager {
  constructor() {
    this.rooms = new Map(); // roomId -> { sockets: Set<socketId>, playerConfigs: [], session: GameSession|null }
  }

  createRoom(roomId) {
    if (this.rooms.has(roomId)) throw new Error(`Room "${roomId}" already exists`);
    const room = { sockets: new Set(), playerConfigs: [null, null], session: null };
    this.rooms.set(roomId, room);
    return room;
  }

  getRoom(roomId) {
    return this.rooms.get(roomId);
  }

  /** @returns {number} the seat index (0 or 1) this socket was assigned, or -1 if the room is full */
  joinRoom(roomId, socketId) {
    const room = this.rooms.get(roomId);
    if (!room) throw new Error(`Room "${roomId}" does not exist`);
    if (room.sockets.size >= 2 && !room.sockets.has(socketId)) return -1;
    room.sockets.add(socketId);
    return [...room.sockets].indexOf(socketId);
  }

  setPlayerConfig(roomId, seatIndex, config) {
    const room = this.rooms.get(roomId);
    if (!room) return;
    room.playerConfigs[seatIndex] = config;
  }

  isReadyToStart(roomId) {
    const room = this.rooms.get(roomId);
    return !!room && room.sockets.size === 2 && room.playerConfigs.every(Boolean) && !room.session;
  }

  removeSocket(socketId) {
    for (const [roomId, room] of this.rooms) {
      if (room.sockets.delete(socketId) && room.sockets.size === 0) {
        this.rooms.delete(roomId); // clean up empty rooms
      }
    }
  }
}

module.exports = RoomManager;
