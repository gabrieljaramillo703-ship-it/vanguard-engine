const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const CARDS_JSON_PATH = path.join(__dirname, "..", "data", "cards.json");

/**
 * api.js
 *
 * GET /api/cards?q=<search>&limit=<n>&offset=<n>
 *   Searches by substring match on card name (case-insensitive). Returns
 *   { total, results } — `total` is the full match count (before limit),
 *   so the client can show "showing 50 of 340" and paginate.
 *
 * GET /api/cards/status
 *   { available: boolean, count: number } — lets the client show a clear
 *   message ("card database still building") instead of a silent empty list
 *   if the scraper (Part 2) hasn't produced data/cards.json yet.
 *
 * Cards are cached in memory and re-read from disk if the file's mtime
 * changes, so a fresh `npm run scrape` run is picked up without restarting
 * the server.
 */

let cache = { mtimeMs: 0, cards: [] };

function loadCards() {
  try {
    const stat = fs.statSync(CARDS_JSON_PATH);
    if (stat.mtimeMs !== cache.mtimeMs) {
      const raw = fs.readFileSync(CARDS_JSON_PATH, "utf-8");
      cache = { mtimeMs: stat.mtimeMs, cards: JSON.parse(raw) };
    }
  } catch {
    cache = { mtimeMs: 0, cards: [] }; // cards.json doesn't exist yet
  }
  return cache.cards;
}

function buildApiRouter() {
  const router = express.Router();
  router.use(cors());
  router.use(express.json());

  router.get("/cards/status", (req, res) => {
    const cards = loadCards();
    res.json({ available: cards.length > 0, count: cards.length });
  });

  router.get("/cards", (req, res) => {
    const cards = loadCards();
    const q = (req.query.q || "").toLowerCase().trim();
    const limit = Math.min(parseInt(req.query.limit, 10) || 50, 200);
    const offset = parseInt(req.query.offset, 10) || 0;

    const matches = q ? cards.filter((c) => c.name.toLowerCase().includes(q)) : cards;
    res.json({
      total: matches.length,
      results: matches.slice(offset, offset + limit),
    });
  });

  return router;
}

module.exports = { buildApiRouter, loadCards };
