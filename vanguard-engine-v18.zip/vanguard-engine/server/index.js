const http = require("http");
const express = require("express");
const { Server } = require("socket.io");
const RoomManager = require("./RoomManager");
const GameSession = require("./GameSession");
const { buildApiRouter } = require("./api");

/**
 * server/index.js
 *
 * Socket.io events (client -> server):
 *   "createRoom"  { roomId }                     -> creates a room, joins as seat 0
 *   "joinRoom"    { roomId }                      -> joins an existing room as seat 1 (or reconnects to your seat)
 *   "submitDeck"  { roomId, name, mainDeckCardIds?, rideDeckCardIds?, gZoneCardIds? }
 *                                                 -> registers this player's deck for the room
 *                                                    (omit all card ids to get a synthetic test
 *                                                    deck while the real database builds)
 *   Once both seats have joined AND both have submitted a deck, the match
 *   starts automatically — no separate "startMatch" event needed.
 *
 * Socket.io events (server -> client), see GameSession.js and
 * SocketController.js for exact payload shapes:
 *   "roomJoined"      { seatIndex }
 *   "matchStarted"    { players: [{name}, {name}] }
 *   "stateUpdate"     public board snapshot (both players' fields, no hands)
 *   "yourHand"        PRIVATE — sent only to your own socket, your hand contents
 *   "matchLog"        { message } — human-readable log line, for a live feed
 *   "decisionRequest" { requestId, type, payload } — sent only to the deciding player
 *   "matchOver"       { winner }
 *   "errorMessage"    { message }
 *
 * Client emits back for decisions: "decisionResponse" { requestId, choice }
 */

const PORT = process.env.PORT || 3001;

const app = express();
app.use("/api", buildApiRouter());

const httpServer = http.createServer(app);
const io = new Server(httpServer, {
  cors: { origin: "*" }, // tighten this to your real frontend's origin before going to production
});

const roomManager = new RoomManager();
const activeSessions = new Map(); // roomId -> GameSession

io.on("connection", (socket) => {
  console.log(`[server] socket connected: ${socket.id}`);

  socket.on("createRoom", ({ roomId }) => {
    try {
      roomManager.createRoom(roomId);
      const seatIndex = roomManager.joinRoom(roomId, socket.id);
      socket.join(roomId);
      socket.data.roomId = roomId;
      socket.data.seatIndex = seatIndex;
      socket.emit("roomJoined", { seatIndex });
    } catch (err) {
      socket.emit("errorMessage", { message: err.message });
    }
  });

  socket.on("joinRoom", ({ roomId }) => {
    try {
      const seatIndex = roomManager.joinRoom(roomId, socket.id);
      if (seatIndex === -1) {
        socket.emit("errorMessage", { message: "Room is full." });
        return;
      }
      socket.join(roomId);
      socket.data.roomId = roomId;
      socket.data.seatIndex = seatIndex;
      socket.emit("roomJoined", { seatIndex });
    } catch (err) {
      socket.emit("errorMessage", { message: err.message });
    }
  });

  socket.on("submitDeck", ({ roomId, name, mainDeckCardIds, rideDeckCardIds, gZoneCardIds }) => {
    const seatIndex = socket.data.seatIndex;
    if (socket.data.roomId !== roomId || seatIndex == null) {
      socket.emit("errorMessage", { message: "You haven't joined this room." });
      return;
    }

    if (mainDeckCardIds || rideDeckCardIds) {
      const validationError = validateDeck(mainDeckCardIds, rideDeckCardIds, gZoneCardIds);
      if (validationError) {
        socket.emit("errorMessage", { message: validationError });
        return;
      }
    }

    roomManager.setPlayerConfig(roomId, seatIndex, { name, mainDeckCardIds, rideDeckCardIds, gZoneCardIds });

    if (roomManager.isReadyToStart(roomId)) {
      startMatch(roomId);
    }
  });

  socket.on("disconnect", () => {
    console.log(`[server] socket disconnected: ${socket.id}`);
    roomManager.removeSocket(socket.id);
  });
});

/**
 * Defense-in-depth: the client's DeckBuilder should already enforce these,
 * but the server never trusts the client. Per the current official rules
 * (en.cf-vanguard.com/howto/fighters_rules/deckrules/): Main Deck is a full
 * 50 cards, fully separate from the 4-card Ride Deck (Grade 0/1/2/3, in
 * order) and the G Zone (up to 8, all Grade 4). The "up to 4 copies" limit
 * applies WITHIN the Main Deck and WITHIN the G Zone independently, not
 * combined across zones — the Ride Deck can't exceed 4 copies of anything
 * by construction (exactly one card per grade).
 */
function validateDeck(mainDeckCardIds, rideDeckCardIds, gZoneCardIds) {
  if (!Array.isArray(mainDeckCardIds) || mainDeckCardIds.length !== 50) {
    return `Main Deck must have exactly 50 cards (got ${mainDeckCardIds?.length ?? 0}).`;
  }
  if (!Array.isArray(rideDeckCardIds) || rideDeckCardIds.length !== 4) {
    return `Ride Deck must have exactly 4 cards, one each of Grade 0/1/2/3 (got ${rideDeckCardIds?.length ?? 0}).`;
  }
  if ((gZoneCardIds || []).length > 8) {
    return "G Zone can have at most 8 cards.";
  }

  const tooManyCopies = (ids) => {
    const counts = {};
    for (const id of ids) counts[id] = (counts[id] || 0) + 1;
    return Object.entries(counts).find(([, count]) => count > 4);
  };

  const mainOverLimit = tooManyCopies(mainDeckCardIds);
  if (mainOverLimit) {
    return `Too many copies of card ${mainOverLimit[0]} in the Main Deck (max 4).`;
  }
  const gZoneOverLimit = tooManyCopies(gZoneCardIds || []);
  if (gZoneOverLimit) {
    return `Too many copies of card ${gZoneOverLimit[0]} in the G Zone (max 4).`;
  }
  return null;
}

function startMatch(roomId) {
  const room = roomManager.getRoom(roomId);
  if (!room) return;

  const seatSockets = [...room.sockets].map((id) => io.sockets.sockets.get(id));
  if (seatSockets.some((s) => !s)) {
    console.error(`[server] room ${roomId}: a seated socket is no longer connected, aborting match start`);
    return;
  }

  const session = new GameSession(io, roomId, seatSockets, room.playerConfigs);
  room.session = session;
  activeSessions.set(roomId, session);

  session.run().catch((err) => {
    console.error(`[server] match in room ${roomId} crashed:`, err);
    io.to(roomId).emit("errorMessage", { message: "The match encountered an internal error and stopped." });
  });
}

httpServer.listen(PORT, () => {
  console.log(`[server] listening on port ${PORT}`);
});
