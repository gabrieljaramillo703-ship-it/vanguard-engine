const fs = require("fs");
const path = require("path");
const Card = require("../src/Card");
const { attachEffects } = require("../data/cardEffects");
const { buildTestDeck } = require("../data/testCards");

const CARDS_JSON_PATH = path.join(__dirname, "..", "data", "cards.json");

/**
 * loadDeck.js
 *
 * Two ways to get a deck for a match:
 *   1. Real cards: pass mainDeckCardIds (50, from data/cards.json),
 *      rideDeckCardIds (4, ordered Grade 0->3), and gZoneCardIds (0-8,
 *      Grade 4 Stride units) — all three are separate zones, per the
 *      current official rules. Used once the scraper has produced real
 *      data and the client's DeckBuilder has assigned cards to each zone.
 *   2. Fallback: if cards.json doesn't exist yet, or no ids are given,
 *      generates a synthetic Standard-shaped test deck (see data/testCards.js)
 *      so matches can still be played while the real database builds.
 */

let cachedDatabase = null;

function loadCardDatabase() {
  if (cachedDatabase) return cachedDatabase;
  try {
    const raw = fs.readFileSync(CARDS_JSON_PATH, "utf-8");
    const parsed = JSON.parse(raw);
    cachedDatabase = new Map(parsed.map((c) => [c.id, c]));
  } catch {
    cachedDatabase = new Map(); // cards.json not ready yet
  }
  return cachedDatabase;
}

/**
 * @param {Object} [deckConfig]
 * @param {string[]} [deckConfig.mainDeckCardIds] 50 ids into data/cards.json
 * @param {string[]} [deckConfig.rideDeckCardIds] 4 ids, ordered Grade 0->3
 * @param {string[]} [deckConfig.gZoneCardIds] 0-8 ids, Grade 4 Stride units
 * @param {string} [deckConfig.namePrefix] Only used for the synthetic fallback deck
 * @returns {{ mainDeckCards: Card[], rideDeck: Card[], gZone: Card[] }}
 */
function loadDeck(deckConfig = {}) {
  const db = loadCardDatabase();
  const { mainDeckCardIds, rideDeckCardIds, gZoneCardIds } = deckConfig;

  if (mainDeckCardIds && rideDeckCardIds && db.size > 0) {
    const resolve = (id) => {
      const def = db.get(id);
      return def ? attachEffects(new Card(def)) : null;
    };

    const mainDeckCards = mainDeckCardIds.map(resolve).filter(Boolean);
    const rideDeck = rideDeckCardIds.map(resolve).filter(Boolean);
    const gZone = (gZoneCardIds || []).map(resolve).filter(Boolean);

    if (mainDeckCards.length === mainDeckCardIds.length && rideDeck.length === 4) {
      return { mainDeckCards, rideDeck, gZone };
    }
    console.warn("[loadDeck] real card ids given but couldn't resolve a full deck — falling back to a synthetic test deck");
  }

  return buildTestDeck(deckConfig.namePrefix || "P");
}

module.exports = { loadDeck, loadCardDatabase };
