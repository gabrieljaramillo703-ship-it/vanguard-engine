const { io } = require("socket.io-client");

/**
 * server/testClient.js
 * Usage: node server/testClient.js
 *
 * Connects two sockets (simulating two real players) to a locally running
 * server (`npm run server` in another terminal first), creates a room,
 * joins it, submits two synthetic test decks, and auto-answers every
 * decisionRequest with simple logic — similar to what AIController does,
 * but happening on the CLIENT side this time, proving the server's
 * decisionRequest/decisionResponse protocol actually works end-to-end.
 *
 * This is a stand-in for a real UI: swap the auto-answer logic below for
 * actual user input (button clicks, etc.) and this becomes the real thing.
 */

const SERVER_URL = process.env.SERVER_URL || "http://localhost:3001";
const ROOM_ID = `test-${Date.now()}`;

function makeAutoPlayer(label) {
  const socket = io(SERVER_URL);

  socket.on("connect", () => console.log(`[${label}] connected as ${socket.id}`));
  socket.on("errorMessage", (e) => console.error(`[${label}] ERROR: ${e.message}`));
  socket.on("roomJoined", ({ seatIndex }) => console.log(`[${label}] joined room as seat ${seatIndex}`));
  socket.on("matchStarted", ({ players }) => console.log(`[${label}] match started: ${players.map((p) => p.name).join(" vs ")}`));
  socket.on("matchLog", ({ message }) => console.log(`[log] ${message}`));
  socket.on("matchOver", ({ winner }) => {
    console.log(`[${label}] MATCH OVER — winner: ${winner}`);
    socket.close();
  });
  socket.on("yourHand", ({ hand }) => {
    socket.currentHand = hand; // stash for decision-making below
  });

  // Auto-answer every decision with simple logic (mirrors AIController).
  socket.on("decisionRequest", ({ requestId, type, payload }) => {
    let choice = null;

    switch (type) {
      case "chooseRide":
        // Discard the first card in hand as the ride cost (mirrors AIController's approach, simplified).
        choice = payload.hand.length > 0 ? { discardCardIndex: 0 } : null;
        break;
      case "chooseStride":
        // Discard cards until their grades sum to 3+, same idea as AIController.
        {
          const sortedIdx = payload.hand
            .map((c, i) => ({ i, grade: c.grade }))
            .sort((a, b) => a.grade - b.grade);
          const discardIndices = [];
          let sum = 0;
          for (const { i, grade } of sortedIdx) {
            if (sum >= 3) break;
            discardIndices.push(i);
            sum += grade;
          }
          choice = sum >= 3 ? { strideIndex: 0, discardIndices } : null;
        }
        break;
      case "chooseNextCall":
        choice =
          payload.candidates.length > 0 && payload.openSlots.length > 0
            ? { cardIndex: 0, slot: payload.openSlots[0] }
            : null;
        break;
      case "chooseNextAttacker":
        choice = payload.candidates.length > 0 ? 0 : null; // attack with the first available unit
        break;
      case "chooseGuardians":
        choice = []; // simple test player never guards
        break;
    }

    console.log(`[${label}] answering ${type} ->`, JSON.stringify(choice));
    socket.emit("decisionResponse", { requestId, choice });
  });

  return socket;
}

const player1 = makeAutoPlayer("Player1");

player1.on("connect", () => {
  player1.emit("createRoom", { roomId: ROOM_ID });
});
player1.on("roomJoined", () => {
  player1.emit("submitDeck", { roomId: ROOM_ID, name: "Gabriel" }); // no cardIds -> synthetic test deck

  // Second player joins shortly after the room exists.
  const player2 = makeAutoPlayer("Player2");
  player2.on("connect", () => {
    player2.emit("joinRoom", { roomId: ROOM_ID });
  });
  player2.on("roomJoined", () => {
    player2.emit("submitDeck", { roomId: ROOM_ID, name: "CPU2" });
  });
});
