class Deck {
  constructor(cards) {
    this.cards = [...cards]; // top of deck = index 0
  }

  shuffle(rng = Math.random) {
    for (let i = this.cards.length - 1; i > 0; i--) {
      const j = Math.floor(rng() * (i + 1));
      [this.cards[i], this.cards[j]] = [this.cards[j], this.cards[i]];
    }
    return this;
  }

  draw(n = 1) {
    return this.cards.splice(0, n);
  }

  get count() {
    return this.cards.length;
  }

  get isEmpty() {
    return this.cards.length === 0;
  }
}

module.exports = Deck;
