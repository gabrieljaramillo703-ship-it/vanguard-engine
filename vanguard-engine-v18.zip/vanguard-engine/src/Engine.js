const GameState = require("./GameState");
const EffectSystem = require("./effects/EffectSystem");
const { applyTrigger } = require("./effects/TriggerResolution");
const AIController = require("./controllers/AIController");

/**
 * Engine.js
 *
 * WHAT'S AUTOMATIC vs WHAT'S A PLAYER DECISION — this split is the whole
 * point of this file, so it's worth stating plainly:
 *
 *   AUTOMATIC (the engine always does this itself, no one is asked):
 *     - Power totals: base + boost from the back-row unit + any contPower
 *       effects (getUnitPower())
 *     - Shield totals once guardians are chosen
 *     - Trigger unit resolution (critical/draw/front/heal/over) per
 *       Standard-format rules — see TriggerResolution.js
 *     - Drive checks and damage checks (which deck, what happens on a hit)
 *     - Firing card effect hooks (onRide, onAttack, onBoost, etc.) — see
 *       EffectSystem.js and EffectHooks.js
 *     - Win condition checks, hand-size discard at end of turn
 *
 *   PLAYER DECISIONS (the engine asks a Controller and awaits the answer):
 *     - Whether/what to ride this turn         -> chooseRide()
 *     - What to call, one at a time, and where -> chooseNextCall()
 *     - Which units attack, and in what order  -> chooseNextAttacker()
 *     - Which guardians (if any) to use        -> chooseGuardians()
 *
 * A Controller is anything implementing src/controllers/Controller.js.
 * AIController (heuristic) is the default so existing demos/tests keep
 * working unchanged; server/GameSession.js plugs in SocketController for a
 * real connected player instead — Engine.js itself never knows the
 * difference.
 *
 * Card effects resolve through EffectSystem (src/effects/) at the hooks
 * documented in EffectHooks.js. Named/unique card skills are hand-authored
 * per card in data/cardEffects.js and attached to Card.effects by id;
 * nothing here parses skill text into logic.
 */
class Engine {
  /**
   * @param {import("./Player")} player1
   * @param {import("./Player")} player2
   * @param {Object} [options]
   * @param {import("./controllers/Controller")} [options.controller1] defaults to AIController
   * @param {import("./controllers/Controller")} [options.controller2] defaults to AIController
   * @param {boolean} [options.verbose=true]
   */
  constructor(player1, player2, { controller1, controller2, verbose = true } = {}) {
    this.state = new GameState(player1, player2);
    this.effects = new EffectSystem(this.state);
    this.verbose = verbose;
    this.controllers = new Map([
      [player1, controller1 || new AIController()],
      [player2, controller2 || new AIController()],
    ]);
  }

  controllerFor(player) {
    return this.controllers.get(player);
  }

  log(msg) {
    this.state.note(msg);
    if (this.verbose) console.log(this.state.log[this.state.log.length - 1]);
  }

  // ---------- Main loop ----------

  async playGame(maxTurns = 100) {
    while (!this.state.winner && this.state.turnNumber <= maxTurns) {
      await this.runPhase();
      if (this.state.checkForWinner()) break;
      this.state.advancePhase();
    }
    if (this.state.winner) {
      this.log(`GAME OVER — winner: ${this.state.winner.name}`);
    } else {
      this.log("GAME OVER — turn limit reached, no winner");
    }
    return this.state;
  }

  async runPhase() {
    switch (this.state.currentPhase) {
      case "stand":
        return this.standPhase();
      case "draw":
        return this.drawPhase();
      case "ride":
        return this.ridePhase();
      case "main":
        return this.mainPhase();
      case "battle":
        return this.battlePhase();
      case "end":
        return this.endPhase();
    }
  }

  // ---------- Phases ----------

  standPhase() {
    const p = this.state.turnPlayer;
    p.standAll();
    p.resetTurnState();
    this.log(`${p.name} stands all units.`);
  }

  drawPhase() {
    const p = this.state.turnPlayer;
    if (this.state.isFirstTurnOfGame()) {
      this.log(`${p.name} skips draw (first turn of the game).`);
      return;
    }
    const drawn = p.drawCards(1);
    this.log(`${p.name} draws ${drawn.length} card(s). Hand size: ${p.hand.length}`);
  }

  async ridePhase() {
    const p = this.state.turnPlayer;
    const opponent = this.state.opponent;
    const nextRideCard = p.peekNextRide();
    const strideUnlocked = p.vanguardCircle.grade >= 3 && opponent.vanguardCircle.grade >= 3 && p.gZone.length > 0;
    const controller = this.controllerFor(p);

    if (!nextRideCard && !strideUnlocked) {
      this.log(`${p.name} has no ride or Stride available this turn.`);
      return;
    }

    // Normal case: Ride Deck still has a card queued up (Grades 1-3).
    // Stride only becomes relevant once the Ride Deck is exhausted (Grade 3
    // reached) — see the class-level note on Player.js for why these two
    // essentially never overlap in practice.
    if (nextRideCard) {
      const decision = await controller.chooseRide(nextRideCard, p.hand);
      if (!decision) {
        this.log(`${p.name} chooses not to ride this turn.`);
        return;
      }
      if (!p.hand.includes(decision.discardCard)) {
        this.log(`${p.name}'s ride cost was invalid — skipping ride.`);
        return;
      }
      p.hand = p.hand.filter((c) => c !== decision.discardCard);
      p.dropZone.push(decision.discardCard);
      p.rideDeck.shift(); // remove the card we just rode from the queue
      p.soul.push(p.vanguardCircle);
      p.vanguardCircle = nextRideCard;
      this.log(`${p.name} rides ${nextRideCard.name} (Grade ${nextRideCard.grade}) from the Ride Deck, discarding ${decision.discardCard.name}.`);
      this.effects.runHook("onRide", { target: nextRideCard });
      this.effects.runHook("onPlaceVC", { target: nextRideCard });
      return;
    }

    // Ride Deck exhausted — Stride is the only option, if unlocked.
    if (strideUnlocked) {
      const decision = await controller.chooseStride(p.gZone, p.hand);
      if (!decision) {
        this.log(`${p.name} chooses not to Stride this turn.`);
        return;
      }
      const gradeSum = decision.discardCards.reduce((sum, c) => sum + c.grade, 0);
      const allInHand = decision.discardCards.every((c) => p.hand.includes(c));
      if (gradeSum < 3 || !allInHand || !p.gZone.includes(decision.strideCard)) {
        this.log(`${p.name}'s Stride cost was invalid — skipping Stride.`);
        return;
      }
      for (const c of decision.discardCards) {
        p.hand = p.hand.filter((x) => x !== c);
        p.dropZone.push(c);
      }
      p.soul.push(p.vanguardCircle);
      p.vanguardCircle = decision.strideCard;
      this.log(
        `${p.name} Strides into ${decision.strideCard.name} (Grade 4), discarding ${decision.discardCards.map((c) => c.name).join(", ")}.`
      );
      this.effects.runHook("onRide", { target: decision.strideCard });
      this.effects.runHook("onPlaceVC", { target: decision.strideCard });
    }
  }

  async mainPhase() {
    const p = this.state.turnPlayer;
    const controller = this.controllerFor(p);

    // Player calls units one at a time until they stop, run out of open
    // slots, or run out of callable cards — same shape as a real main phase.
    for (;;) {
      const openSlots = p.emptyRearGuardSlots();
      if (openSlots.length === 0) {
        this.log(`${p.name} has no open rear guard slots.`);
        break;
      }
      const callable = p.hand.filter((c) => c.cardType === "unit" && c.grade <= p.vanguardCircle.grade);
      if (callable.length === 0) break;

      const choice = await controller.chooseNextCall(callable, openSlots);
      if (!choice) break; // player is done calling

      const { card, slot } = choice;
      if (!callable.includes(card) || !openSlots.includes(slot)) {
        this.log(`${p.name}'s call choice was invalid — stopping main phase calls.`);
        break;
      }

      p.rearGuard[slot] = card;
      p.hand = p.hand.filter((c) => c !== card);
      this.log(`${p.name} calls ${card.name} to ${slot}.`);
      this.effects.runHook("onPlaceRC", { target: card });
    }
  }

  async battlePhase() {
    const attacker = this.state.turnPlayer;
    const defender = this.state.opponent;
    const controller = this.controllerFor(attacker);

    for (;;) {
      const availableAttackers = [
        { unit: attacker.vanguardCircle, slot: "vanguard" },
        { unit: attacker.rearGuard.frontLeft, slot: "frontLeft" },
        { unit: attacker.rearGuard.frontRight, slot: "frontRight" },
      ].filter((a) => a.unit && !a.unit.isRested);

      if (availableAttackers.length === 0) break;

      const choice = await controller.chooseNextAttacker(availableAttackers);
      if (!choice) break; // player is done attacking this turn

      const match = availableAttackers.find((a) => a.unit === choice.unit && a.slot === choice.slot);
      if (!match) {
        this.log(`${attacker.name}'s attacker choice was invalid — stopping battle phase.`);
        break;
      }

      await this.resolveAttack(attacker, defender, match.unit, match.slot);
      if (this.state.checkForWinner()) return;
    }
  }

  /** Card.totalPower (base + trigger bonuses this turn) plus any contPower effects. */
  getUnitPower(unit, owner) {
    return unit.totalPower + this.effects.getContinuousPowerBonus(unit, owner);
  }

  async resolveAttack(attacker, defender, unit, slot) {
    unit.isRested = true;
    this.effects.runHook("onAttack", { target: unit });

    // Boost from the back row unit, if any — automatic, not a decision.
    const booster = attacker.boosterFor(slot);
    if (booster) this.effects.runHook("onBoost", { source: booster, target: unit });
    const boostPower = booster ? this.getUnitPower(booster, attacker) : 0;
    const isVanguardAttack = slot === "vanguard";

    let attackPower = this.getUnitPower(unit, attacker) + boostPower;
    this.log(
      `${attacker.name}'s ${unit.name} (${slot}) attacks ${defender.name}'s vanguard. Base attack: ${attackPower}${booster ? ` (boosted by ${booster.name})` : ""}.`
    );

    // --- Drive check (automated) — attacker's own deck, vanguard attacks only ---
    if (isVanguardAttack) {
      for (let i = 0; i < unit.drive; i++) {
        this.driveCheck(attacker, unit);
      }
      attackPower = this.getUnitPower(unit, attacker) + boostPower; // trigger bonuses may have changed it
    }

    // --- Guard step (defender's decision; totals are automatic) ---
    this.effects.runHook("beforeGuard", { target: defender.vanguardCircle });
    const defenderPower = this.getUnitPower(defender.vanguardCircle, defender);
    const guardResult = await this.resolveGuard(defender, {
      attackerName: unit.name,
      attackPower,
      defendingVanguardPower: defenderPower,
      dangerZone: defender.damageCount >= 3,
    });
    const totalDefensePower = defenderPower + guardResult.shieldAdded;

    const hits = attackPower > totalDefensePower;
    this.log(
      `Defense: vanguard ${defenderPower} + shield ${guardResult.shieldAdded} = ${totalDefensePower}. Attack ${hits ? "HITS" : "is guarded/blocked"}.`
    );

    if (!hits) return;

    // --- Damage check (automated) — defender's own deck ---
    const critical = isVanguardAttack ? unit.critical : 1;
    for (let i = 0; i < critical; i++) {
      this.damageCheck(defender, attacker);
      if (this.state.checkForWinner()) return;
    }
  }

  /** Attacker checks their own deck; trigger effects (if any) benefit the attacker. */
  driveCheck(attacker, attackingUnit) {
    const drawn = attacker.deck.draw(1);
    if (drawn.length === 0) {
      this.log(`${attacker.name} cannot drive check — deck is empty!`);
      return;
    }
    const card = drawn[0];

    if (card.triggerType === "over") {
      this.log(`${attacker.name} drive checks ${card.name} — OVER TRIGGER! (removed from the game)`);
      this.effects.runHook("onTriggerCheck", { source: card });
      applyTrigger("over", { attacker, attackingUnit, opponentDamageCount: null, log: (msg) => this.log(msg) });
      if (card.overAdditionalEffect) {
        card.overAdditionalEffect({
          state: this.state,
          owner: attacker,
          opponent: this.state.players.find((p) => p !== attacker),
          source: card,
          target: attackingUnit,
          log: (msg) => this.log(msg),
        });
      }
      return;
    }

    attacker.hand.push(card);
    const triggerNote = card.triggerType ? ` — TRIGGER (${card.triggerType})!` : "";
    this.log(`${attacker.name} drive checks ${card.name}${triggerNote}.`);

    if (card.triggerType) {
      this.effects.runHook("onTriggerCheck", { source: card });
      applyTrigger(card.triggerType, {
        attacker,
        attackingUnit,
        opponentDamageCount: null, // drive-check triggers don't use the heal comparison (only damage checks do)
        log: (msg) => this.log(msg),
      });
    }
  }

  /** Asks the defending player's controller which guardians (if any) to use; totals the shield automatically. */
  async resolveGuard(defender, attackInfo) {
    const guardianOptions = defender.hand.filter((c) => c.cardType === "unit" && c.shield > 0);
    let chosen = [];
    if (guardianOptions.length > 0) {
      chosen = await this.controllerFor(defender).chooseGuardians(attackInfo, guardianOptions);
      chosen = chosen.filter((c) => guardianOptions.includes(c)); // ignore anything not actually a legal option
    }

    let shieldAdded = 0;
    for (const g of chosen) {
      defender.hand = defender.hand.filter((c) => c !== g);
      defender.guardianCircle.push(g);
      shieldAdded += g.shield;
      this.log(`${defender.name} guards with ${g.name} (shield ${g.shield}).`);
    }
    defender.dropZone.push(...defender.guardianCircle.splice(0));

    return { shieldAdded };
  }

  damageCheck(defender, attacker) {
    const drawn = defender.deck.draw(1);
    if (drawn.length === 0) {
      this.log(`${defender.name} cannot damage check — deck is empty!`);
      return;
    }
    const card = drawn[0];

    if (card.triggerType === "over") {
      this.log(`${defender.name} damage checks ${card.name} — OVER TRIGGER! (removed from the game, no damage taken)`);
      this.effects.runHook("onTriggerCheck", { source: card });
      applyTrigger("over", {
        attacker: defender,
        attackingUnit: defender.vanguardCircle,
        opponentDamageCount: null,
        log: (msg) => this.log(msg),
      });
      return;
    }

    defender.damageZone.push(card);
    const triggerNote = card.triggerType ? ` — TRIGGER (${card.triggerType})!` : "";
    this.log(`${defender.name} takes damage: checks ${card.name}${triggerNote}. Damage: ${defender.damageCount}/6`);

    if (card.triggerType) {
      this.effects.runHook("onTriggerCheck", { source: card });
      applyTrigger(card.triggerType, {
        attacker: defender,
        attackingUnit: defender.vanguardCircle,
        opponentDamageCount: attacker.damageCount,
        log: (msg) => this.log(msg),
      });
    }

    this.effects.runHook("onDamageTaken", { target: defender.vanguardCircle, amount: 1 });
  }

  endPhase() {
    const p = this.state.turnPlayer;
    if (p.hand.length > 7) {
      const excess = p.hand.length - 7;
      const discarded = p.hand.splice(0, excess);
      p.dropZone.push(...discarded);
      this.log(`${p.name} discards ${excess} card(s) to hand size limit.`);
    }
    this.log(`${p.name} ends turn.`);
  }
}

module.exports = Engine;
