const PHASES = ["stand", "draw", "ride", "main", "battle", "end"];

class GameState {
  constructor(player1, player2) {
    this.players = [player1, player2];
    this.turnPlayerIndex = 0;
    this.turnNumber = 1;
    this.phaseIndex = 0;
    this.winner = null;
    this.log = [];
  }

  get turnPlayer() {
    return this.players[this.turnPlayerIndex];
  }

  get opponent() {
    return this.players[1 - this.turnPlayerIndex];
  }

  get currentPhase() {
    return PHASES[this.phaseIndex];
  }

  isFirstTurnOfGame() {
    return this.turnNumber === 1;
  }

  advancePhase() {
    this.phaseIndex++;
    if (this.phaseIndex >= PHASES.length) {
      this.phaseIndex = 0;
      this.turnPlayerIndex = 1 - this.turnPlayerIndex;
      this.turnNumber++;
    }
  }

  checkForWinner() {
    for (const p of this.players) {
      if (p.isDefeated) {
        this.winner = this.players.find((x) => x !== p);
      }
      if (p.deck.isEmpty) {
        // Deck-out loss: the player who cannot draw loses
        this.winner = this.players.find((x) => x !== p);
      }
    }
    return this.winner;
  }

  note(message) {
    this.log.push(`[T${this.turnNumber} ${this.turnPlayer.name} - ${this.currentPhase}] ${message}`);
  }
}

GameState.PHASES = PHASES;
module.exports = GameState;
