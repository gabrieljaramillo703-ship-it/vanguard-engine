const Deck = require("./Deck");

/**
 * Rear guard circle positions used throughout the engine:
 *   frontLeft, frontRight   -> front row, can attack and be attacked
 *   backLeft, backRight     -> back row, can boost the unit in front of them
 *   frontCenter             -> only usable in some formats; kept null/unused for now
 */
const RG_SLOTS = ["backLeft", "frontLeft", "frontCenter", "frontRight", "backRight"];

/**
 * DECK CONSTRUCTION (confirmed via en.cf-vanguard.com/howto/fighters_rules/deckrules/,
 * the current live tournament rules page — supersedes an earlier announcement
 * page that described a different, now-outdated version of this mechanic):
 *   - Main Deck: 50 cards, a fully separate zone from the Ride Deck.
 *   - Ride Deck: 4 cards — one each of Grade 0/1/2/3 — plus optionally a
 *     "Ride Deck Crest" as a 5th card (not modeled yet, see below). The
 *     Grade 0 is the First Vanguard. Riding through the Ride Deck is
 *     guaranteed (no need to draw the next grade), but each ride still
 *     costs discarding a card from hand.
 *   - G Zone (Stride): up to 8 Grade 4 "Stride" units, also separate from
 *     the Main Deck. Stride unlocks once BOTH vanguards are Grade 3+, and
 *     costs discarding card(s) from hand whose grades sum to 3 or more.
 *   - The "up to 4 copies of a card" limit applies WITHIN the Main Deck and
 *     WITHIN the G Zone independently — not combined across zones. The Ride
 *     Deck can't exceed 4 copies of anything by construction (exactly one
 *     card per grade).
 *
 * SIMPLIFICATIONS (documented, not silently done):
 *   - The Ride Deck Crest (optional 5th ride-deck card, a resource-style
 *     card rather than a unit) isn't modeled yet.
 *   - Real paper Stride tracks each G Zone card as face-down/face-up
 *     individually, and some cards have unique alternate Stride costs. This
 *     engine treats every G Zone card as always available with the same
 *     base cost every time.
 */
class Player {
  /**
   * @param {string} name
   * @param {import("./Card")[]} mainDeckCards the 50-card Main Deck (fully separate from the Ride Deck)
   * @param {import("./Card")[]} rideDeck exactly 4 cards, ordered Grade 0 -> 3
   * @param {import("./Card")[]} [gZone] up to 8 Grade 4 Stride units
   */
  constructor(name, mainDeckCards, rideDeck, gZone = []) {
    this.name = name;
    this.deck = new Deck(mainDeckCards).shuffle();
    this.rideDeck = [...rideDeck]; // remaining un-ridden cards, ordered by grade ascending
    this.gZone = [...gZone];

    this.hand = [];
    this.rearGuard = { backLeft: null, frontLeft: null, frontCenter: null, frontRight: null, backRight: null };
    this.damageZone = []; // cards face up once checked, face down (hidden) until checked
    this.dropZone = [];
    this.soul = []; // cards under the vanguard (from ride/Stride)
    this.guardianCircle = []; // cards temporarily placed to guard, resolved then moved to drop

    // Grade 0 from the Ride Deck is the First Vanguard, set up immediately.
    this.vanguardCircle = this.rideDeck.shift() ?? null;
  }

  get damageCount() {
    return this.damageZone.length;
  }

  get isDefeated() {
    return this.damageCount >= 6;
  }

  drawCards(n) {
    const drawn = this.deck.draw(n);
    this.hand.push(...drawn);
    return drawn;
  }

  /** The next guaranteed ride from the Ride Deck, or null if it's been fully used (Grade 3 reached). */
  peekNextRide() {
    return this.rideDeck[0] ?? null;
  }

  allFrontRow() {
    return [this.rearGuard.frontLeft, this.vanguardCircle, this.rearGuard.frontRight].filter(Boolean);
  }

  allRearGuards() {
    return RG_SLOTS.map((slot) => this.rearGuard[slot]).filter(Boolean);
  }

  boosterFor(slot) {
    if (slot === "frontLeft") return this.rearGuard.backLeft;
    if (slot === "frontRight") return this.rearGuard.backRight;
    return null;
  }

  emptyRearGuardSlots() {
    return RG_SLOTS.filter((slot) => !this.rearGuard[slot]);
  }

  standAll() {
    if (this.vanguardCircle) this.vanguardCircle.isRested = false;
    this.allRearGuards().forEach((c) => (c.isRested = false));
  }

  resetTurnState() {
    if (this.vanguardCircle) this.vanguardCircle.resetTurnState();
    this.allRearGuards().forEach((c) => c.resetTurnState());
  }
}

Player.RG_SLOTS = RG_SLOTS;
module.exports = Player;
