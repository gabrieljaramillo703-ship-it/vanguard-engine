const Controller = require("./Controller");

/**
 * AIController.js
 *
 * The heuristic decision-making that used to be hardcoded inside Engine.js.
 * Used for: solo practice mode (player vs AI), demos, and automated tests
 * where nobody needs to actually click anything. A real human player uses
 * SocketController instead — same interface, so Engine.js never needs to
 * know which one it's talking to.
 */
class AIController extends Controller {
  async chooseRide(nextRideCard, hand) {
    if (!nextRideCard) return null; // Ride Deck exhausted
    if (hand.length === 0) return null; // can't pay the discard cost
    // Discard the lowest-power card to preserve the strongest hand.
    const discardCard = [...hand].sort((a, b) => a.power - b.power)[0];
    return { discardCard };
  }

  async chooseStride(gZoneCandidates, hand) {
    if (gZoneCandidates.length === 0) return null;
    // Pay the minimum viable cost: cheapest (lowest-grade) cards first until
    // their grades sum to 3 or more.
    const sorted = [...hand].sort((a, b) => a.grade - b.grade);
    const discardCards = [];
    let gradeSum = 0;
    for (const c of sorted) {
      if (gradeSum >= 3) break;
      discardCards.push(c);
      gradeSum += c.grade;
    }
    if (gradeSum < 3) return null; // not enough hand to pay the Stride cost
    const strideCard = [...gZoneCandidates].sort((a, b) => b.power - a.power)[0];
    return { strideCard, discardCards };
  }

  async chooseNextCall(callableCards, openSlots) {
    if (callableCards.length === 0 || openSlots.length === 0) return null;
    const card = [...callableCards].sort((a, b) => b.power - a.power)[0];
    const slot = openSlots.find((s) => s === "frontLeft" || s === "frontRight") ?? openSlots[0];
    return { card, slot };
  }

  async chooseNextAttacker(availableAttackers) {
    // Attack with everything available, in the given order.
    return availableAttackers.length > 0 ? availableAttackers[0] : null;
  }

  async chooseGuardians(attackInfo, guardianOptions) {
    const marginNeeded = attackInfo.attackPower - attackInfo.defendingVanguardPower;
    if (marginNeeded <= 0) return []; // already safe
    if (!attackInfo.dangerZone) return []; // heuristic: don't guard early, save hand

    const chosen = [];
    let shieldSoFar = 0;
    for (const g of [...guardianOptions].sort((a, b) => b.shield - a.shield)) {
      if (shieldSoFar >= marginNeeded) break;
      chosen.push(g);
      shieldSoFar += g.shield;
    }
    return chosen;
  }
}

module.exports = AIController;
