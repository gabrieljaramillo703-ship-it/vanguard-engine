/**
 * Controller.js
 *
 * A Controller is whoever makes decisions for one player: ride timing, what
 * to call, who to attack with, how to guard. The engine calls these methods
 * at each decision point and awaits the result — it doesn't care whether
 * the answer came from a human (SocketController, asking a real person over
 * the network) or a heuristic (AIController, used for solo practice, demos,
 * and automated testing).
 *
 * Everything that is NOT a decision — power totals (base + boost + continuous
 * effects), shield totals once guardians are chosen, trigger resolution,
 * drive/damage checks, card effects — stays inside Engine.js and always
 * runs automatically, regardless of which Controller is plugged in.
 */
class Controller {
  /**
   * The Ride Deck guarantees which card comes next (Grade 0-3) — there's no
   * choice of WHICH card, only whether to ride at all and which card to pay
   * the cost with (discard 1 card from hand).
   * @param {import("../Card")|null} nextRideCard the guaranteed next card, or null if the Ride Deck is exhausted (Grade 3 reached)
   * @param {import("../Card")[]} hand
   * @returns {Promise<{discardCard: import("../Card")}|null>} null = skip riding this turn
   */
  async chooseRide(nextRideCard, hand) {
    throw new Error("chooseRide() must be implemented");
  }

  /**
   * Only called when Stride is unlocked (both vanguards Grade 3+) and the
   * player has at least one G Zone card. Cost is discarding hand cards
   * whose grades sum to 3 or more.
   * @param {import("../Card")[]} gZoneCandidates
   * @param {import("../Card")[]} hand
   * @returns {Promise<{strideCard: import("../Card"), discardCards: import("../Card")[]}|null>} null = don't Stride this turn
   */
  async chooseStride(gZoneCandidates, hand) {
    throw new Error("chooseStride() must be implemented");
  }

  /**
   * Called once per main phase. Player may call as many units as they want,
   * one at a time, until they choose to stop or run out of slots/cards.
   * @param {import("../Card")[]} callableCards units in hand playable at the vanguard's grade or below
   * @param {string[]} openSlots empty rear-guard slot names
   * @returns {Promise<{card: import("../Card"), slot: string}|null>} one call, or null to stop calling
   */
  async chooseNextCall(callableCards, openSlots) {
    throw new Error("chooseNextCall() must be implemented");
  }

  /**
   * @param {{unit: import("../Card"), slot: string}[]} availableAttackers untapped units that can attack this turn
   * @returns {Promise<{unit: import("../Card"), slot: string}|null>} which one to attack with next, or null to stop attacking
   */
  async chooseNextAttacker(availableAttackers) {
    throw new Error("chooseNextAttacker() must be implemented");
  }

  /**
   * @param {Object} attackInfo { attackerName, attackPower, defendingVanguardPower }
   * @param {import("../Card")[]} guardianOptions units in hand that could guard (have shield > 0)
   * @returns {Promise<import("../Card")[]>} guardians to use (may be empty — take the hit unguarded)
   */
  async chooseGuardians(attackInfo, guardianOptions) {
    throw new Error("chooseGuardians() must be implemented");
  }
}

module.exports = Controller;
