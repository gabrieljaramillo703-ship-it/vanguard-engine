const { randomUUID } = require("crypto");
const Controller = require("./Controller");

/**
 * SocketController.js
 *
 * This is what makes the game actually playable instead of just watchable:
 * every decision point (ride, call, attack, guard) sends a request to a real
 * person's client over Socket.io and waits for their answer, instead of an
 * AI heuristic deciding on its own.
 *
 * Protocol (see server/GameSession.js for how these are wired to Socket.io):
 *   Server emits "decisionRequest": { requestId, type, payload }
 *   Client emits "decisionResponse": { requestId, choice }
 * `choice` is whatever shape the specific decision type expects (an index
 * into the candidates the server sent, or an array of indices for
 * multi-select decisions like guarding). This controller sends the actual
 * Card objects in payload so the client can render them, but only ever
 * trusts an INDEX back — never accepts a client-supplied card object,
 * since that would let a modified client claim to guard with a card it
 * doesn't actually have.
 */
class SocketController extends Controller {
  constructor(socket, { timeoutMs = 30000 } = {}) {
    super();
    this.socket = socket;
    this.timeoutMs = timeoutMs;
  }

  async chooseRide(nextRideCard, hand) {
    if (!nextRideCard) return null;
    if (hand.length === 0) return null;
    const choice = await this.ask("chooseRide", {
      nextRideCard: summarize(nextRideCard),
      hand: hand.map(summarize),
      allowSkip: true,
    });
    if (choice === null) return null;
    const discardCard = hand[choice.discardCardIndex];
    if (!discardCard) return null; // invalid response — treat as "skip"
    return { discardCard };
  }

  async chooseStride(gZoneCandidates, hand) {
    if (gZoneCandidates.length === 0) return null;
    const choice = await this.ask("chooseStride", {
      candidates: gZoneCandidates.map(summarize),
      hand: hand.map(summarize),
      allowSkip: true,
    });
    if (choice === null) return null;
    const strideCard = gZoneCandidates[choice.strideIndex];
    const discardCards = (choice.discardIndices || []).map((i) => hand[i]).filter(Boolean);
    const gradeSum = discardCards.reduce((sum, c) => sum + c.grade, 0);
    if (!strideCard || gradeSum < 3) {
      return null; // invalid/insufficient response — treat as "don't Stride"
    }
    return { strideCard, discardCards };
  }

  async chooseNextCall(callableCards, openSlots) {
    if (callableCards.length === 0 || openSlots.length === 0) return null;
    const choice = await this.ask("chooseNextCall", {
      candidates: callableCards.map(summarize),
      openSlots,
      allowSkip: true,
    });
    if (choice === null) return null;
    const { cardIndex, slot } = choice;
    const card = callableCards[cardIndex];
    if (!card || !openSlots.includes(slot)) return null; // invalid response — treat as "stop calling"
    return { card, slot };
  }

  async chooseNextAttacker(availableAttackers) {
    if (availableAttackers.length === 0) return null;
    const choice = await this.ask("chooseNextAttacker", {
      candidates: availableAttackers.map((a) => ({ ...summarize(a.unit), slot: a.slot })),
      allowSkip: true,
    });
    return choice === null ? null : availableAttackers[choice] ?? null;
  }

  async chooseGuardians(attackInfo, guardianOptions) {
    if (guardianOptions.length === 0) return [];
    const choice = await this.ask("chooseGuardians", {
      attackInfo,
      candidates: guardianOptions.map(summarize),
    });
    if (!Array.isArray(choice)) return [];
    return choice.map((i) => guardianOptions[i]).filter(Boolean);
  }

  /** Sends a decisionRequest and waits for the matching decisionResponse, or times out. */
  ask(type, payload) {
    return new Promise((resolve) => {
      const requestId = randomUUID();
      let settled = false;

      const onResponse = (msg) => {
        if (msg.requestId !== requestId) return;
        if (settled) return;
        settled = true;
        this.socket.off("decisionResponse", onResponse);
        clearTimeout(timer);
        resolve(msg.choice);
      };

      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        this.socket.off("decisionResponse", onResponse);
        // Timeout fallback: treat as "skip"/"no guard" rather than hanging
        // the whole match forever if a player goes idle or disconnects.
        resolve(payload.allowSkip ? null : []);
      }, this.timeoutMs);

      this.socket.on("decisionResponse", onResponse);
      this.socket.emit("decisionRequest", { requestId, type, payload });
    });
  }
}

function summarize(card) {
  return {
    id: card.id,
    name: card.name,
    grade: card.grade,
    power: card.totalPower,
    shield: card.shield,
  };
}

module.exports = SocketController;
