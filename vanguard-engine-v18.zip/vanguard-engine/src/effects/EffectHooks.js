/**
 * EffectHooks.js
 *
 * The engine calls `EffectSystem.runHook(hookName, ctx)` at these specific
 * moments. A card's `effects` array (see Card.js) is a list of
 * { hook, handler, name } entries — the engine doesn't know what any card
 * does, it just fires the hook and lets whichever cards care respond.
 *
 * HOOK LIST (fired by Engine.js — search for these strings there):
 *   "onRide"        — this card was just ridden as vanguard
 *   "onPlaceVC"      — this card entered the vanguard circle (ride or other effect)
 *   "onPlaceRC"      — this card entered a rear guard circle (call or other effect)
 *   "onAttack"       — this card was declared as an attacker, before damage is dealt
 *   "onBoost"        — this card is boosting another unit this battle
 *   "beforeGuard"    — fired on the defending player's units before guard step
 *   "onTriggerCheck" — a trigger unit was flipped during a drive/damage check
 *   "onDamageTaken"  — this player's vanguard just took damage (after the check)
 *   "contPower"      — continuous power modifiers; re-evaluated whenever power
 *                      is read (kept separate from one-shot hooks above)
 *
 * A handler receives one EffectContext and may mutate game state directly
 * (draw cards, change power, move cards between zones). Handlers should be
 * small and explicit — no hidden magic — since the whole point of this
 * layer is that each card's behavior is easy to audit and unit-test.
 */

/**
 * @typedef {Object} EffectContext
 * @property {import("../GameState")} state
 * @property {import("../Player")} owner        The player who controls the source card
 * @property {import("../Player")} opponent     The other player
 * @property {import("../Card")} source         The card whose effect is firing
 * @property {import("../Card")} [target]       Relevant target, if the hook has one
 * @property {number} [amount]                  Relevant numeric payload (e.g. damage dealt)
 * @property {(msg:string)=>void} log            Engine's logger, for consistent output
 */

const HOOKS = [
  "onRide",
  "onPlaceVC",
  "onPlaceRC",
  "onAttack",
  "onBoost",
  "beforeGuard",
  "onTriggerCheck",
  "onDamageTaken",
  "contPower",
];

module.exports = { HOOKS };
