const { HOOKS } = require("./EffectHooks");

/**
 * EffectSystem.js
 *
 * Walks both players' fields and fires any matching effect on any card
 * that registered for the given hook. Order is: turn player's field first
 * (vanguard, then rear guards left-to-right), then the opponent's — this
 * matters for effects that care about "first" (rare, but the official
 * rules do define a resolution order for simultaneous triggers).
 */
class EffectSystem {
  constructor(state) {
    this.state = state;
  }

  /**
   * @param {string} hook one of HOOKS
   * @param {Object} partialCtx everything EXCEPT state/owner/source/log —
   *   those get filled in per-card as we walk the field. Typically you'll
   *   pass { target, amount } here, or nothing at all.
   */
  runHook(hook, partialCtx = {}) {
    if (!HOOKS.includes(hook)) {
      throw new Error(`Unknown effect hook: "${hook}". Add it to EffectHooks.js first.`);
    }

    for (const player of [this.state.turnPlayer, this.state.opponent]) {
      const cardsInPlay = [player.vanguardCircle, ...player.allRearGuards()].filter(Boolean);
      for (const card of cardsInPlay) {
        for (const effect of card.effects) {
          if (effect.hook !== hook) continue;
          const ctx = {
            state: this.state,
            owner: player,
            opponent: this.state.players.find((p) => p !== player),
            source: card,
            log: (msg) => this.state.note(msg),
            ...partialCtx,
          };
          effect.handler(ctx);
        }
      }
    }
  }

  /**
   * Continuous power modifiers are re-computed on demand rather than fired
   * as a one-shot event, since they need to reflect the current board state
   * at the exact moment power is checked (e.g. mid-battle-calculation).
   * Returns the TOTAL bonus from all contPower effects on `card`'s own side.
   */
  getContinuousPowerBonus(card, owner) {
    let bonus = 0;
    for (const effect of card.effects) {
      if (effect.hook !== "contPower") continue;
      const ctx = {
        state: this.state,
        owner,
        opponent: this.state.players.find((p) => p !== owner),
        source: card,
        log: (msg) => this.state.note(msg),
      };
      bonus += effect.handler(ctx) || 0;
    }
    return bonus;
  }
}

module.exports = EffectSystem;
