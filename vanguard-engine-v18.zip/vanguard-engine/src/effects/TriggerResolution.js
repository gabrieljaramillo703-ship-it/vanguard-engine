/**
 * TriggerResolution.js  (Standard format rules)
 *
 * Corrected per official Standard-format rules (V-series reboot onward):
 *   - ALL trigger types give Power+10000 (not +5000 — that was the older,
 *     pre-reboot value and no longer applies in Standard).
 *   - There is NO Stand Trigger in Standard format. Removed.
 *   - Over Trigger added: max 1 per deck. When revealed by EITHER a drive
 *     or damage check: remove the card from the game (it does NOT go to
 *     hand or the damage zone), draw a card, and give one unit Power+100
 *     Million until end of turn. If revealed specifically via a DRIVE
 *     check, its unique additional effect also activates (this varies per
 *     card/nation — see Card.overAdditionalEffect, handled by Engine).
 *
 *   Critical Trigger: Power+10000, Critical+1
 *   Draw Trigger:     Power+10000, draw a card
 *   Front Trigger:    Power+10000 (front-row unit)
 *   Heal Trigger:     Power+10000; if the checking player's damage is
 *                      greater than their opponent's, heal 1 damage —
 *                      but ONLY on a damage check, never a drive check
 *   Over Trigger:     draw a card, Power+100,000,000; additional effect
 *                      only fires on a drive check (handled by Engine,
 *                      since removing the card from play/hand/damage zone
 *                      is Engine's job, not this module's)
 */

const TRIGGER_POWER_BONUS = 10000;
const OVER_TRIGGER_POWER_BONUS = 100_000_000;

function applyTrigger(triggerType, { attacker, attackingUnit, opponentDamageCount, log }) {
  switch (triggerType) {
    case "critical":
      attackingUnit.powerBonus += TRIGGER_POWER_BONUS;
      attackingUnit.critical += 1;
      log(`Critical Trigger: ${attackingUnit.name} gets Power+${TRIGGER_POWER_BONUS} and Critical+1.`);
      break;

    case "draw":
      attackingUnit.powerBonus += TRIGGER_POWER_BONUS;
      attacker.drawCards(1);
      log(`Draw Trigger: ${attackingUnit.name} gets Power+${TRIGGER_POWER_BONUS}. ${attacker.name} draws a card.`);
      break;

    case "front":
      attackingUnit.powerBonus += TRIGGER_POWER_BONUS;
      log(`Front Trigger: ${attackingUnit.name} gets Power+${TRIGGER_POWER_BONUS}.`);
      break;

    case "heal": {
      attackingUnit.powerBonus += TRIGGER_POWER_BONUS;
      let healed = false;
      // The heal half only applies on a damage check, never a drive check —
      // Engine.driveCheck() passes opponentDamageCount: null to skip it here.
      if (opponentDamageCount !== null && attacker.damageCount > opponentDamageCount) {
        const healedCard = attacker.damageZone.pop();
        if (healedCard) {
          attacker.dropZone.push(healedCard);
          healed = true;
        }
      }
      log(
        `Heal Trigger: ${attackingUnit.name} gets Power+${TRIGGER_POWER_BONUS}.${
          healed ? ` ${attacker.name} heals 1 damage.` : " No heal (damage not greater than opponent's, or not a damage check)."
        }`
      );
      break;
    }

    case "over":
      attackingUnit.powerBonus += OVER_TRIGGER_POWER_BONUS;
      attacker.drawCards(1);
      log(`Over Trigger: ${attackingUnit.name} gets Power+${OVER_TRIGGER_POWER_BONUS.toLocaleString()}. ${attacker.name} draws a card.`);
      // NOTE: the card's removal-from-game, and firing its drive-check-only
      // additional effect, are handled by Engine.js right after this call —
      // this module only knows about the universal base effect shared by
      // every Over Trigger, not each card's unique additional effect.
      break;

    default:
      // Not a trigger unit (or unrecognized type) — nothing to do.
      break;
  }
}

module.exports = { applyTrigger, TRIGGER_POWER_BONUS, OVER_TRIGGER_POWER_BONUS };
