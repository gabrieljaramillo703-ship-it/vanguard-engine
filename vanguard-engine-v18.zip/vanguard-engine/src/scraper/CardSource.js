/**
 * CardSource.js
 *
 * Every place we can pull card data from (official site, a fansite, a
 * community API) implements this same interface. That way the weekly job
 * and the rest of the app never care where the data actually came from —
 * swapping or adding a source later means writing one new adapter file,
 * not touching the pipeline.
 */
class CardSource {
  /** @returns {Promise<RawCard[]>} every card currently listed by the source */
  async fetchAll() {
    throw new Error("fetchAll() must be implemented by the adapter");
  }

  /** @returns {string} short id used in logs, e.g. "official-en", "fandom" */
  get id() {
    throw new Error("id getter must be implemented by the adapter");
  }
}

/**
 * @typedef {Object} RawCard  Shape returned by an adapter, BEFORE normalization.
 * Field names intentionally mirror what's usually printed on a card / product
 * page, since that's the easiest thing for an adapter to scrape reliably.
 * @property {string} number        e.g. "D-BT01/003EN"
 * @property {string} name
 * @property {string} clan
 * @property {string} nation
 * @property {string|number} grade
 * @property {string|number} power
 * @property {string|number} shield
 * @property {string|number} critical
 * @property {string} triggerType   raw text, e.g. "Critical Trigger" | "" if none
 * @property {string} cardType      raw text, e.g. "Normal Unit" | "Trigger Unit" | "Order"
 * @property {string} skillText     English ability text as printed
 * @property {string} [imageUrl]
 * @property {string} [setName]
 */

module.exports = CardSource;
