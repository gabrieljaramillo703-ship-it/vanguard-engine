const axios = require("axios");
const cheerio = require("cheerio");
const fs = require("fs");
const path = require("path");
const CardSource = require("./CardSource");

/**
 * FandomAdapter.js  (v2 — corrected selectors + concurrency + resume)
 *
 * Source: https://cardfight.fandom.com/wiki/Category:Cards (26,870 pages
 * confirmed via the category listing — bigger than first estimated, since
 * that count only reflects one page of pagination completing).
 *
 * CONFIRMED real structure (from a live run's actual output, v9's guess was
 * wrong): pages do NOT use a ".portable-infobox" widget. They use a plain
 * table:
 *   <div class="cftable <nation-slug>">
 *     <div class="header">Card Name</div>
 *     <div class="info-main">
 *       <table><tbody>
 *         <tr><td>Name</td><td>Card Name</td></tr>
 *         <tr><td>Grade</td><td>...</td></tr>
 *         ... etc, one row per label/value pair ...
 *       </tbody></table>
 *     </div>
 *   </div>
 * Parsing below reads every <tr>'s first <td> as the label and the rest
 * joined as the value. The nation is also recoverable from cftable's second
 * CSS class (e.g. "stoicheia") as a fallback if there's no explicit
 * "Nation" row — kept as a fallback, not the primary source, in case some
 * pages DO have an explicit row.
 *
 * SCALE: 26,870 pages, one HTTP request each, cannot be done as a single
 * slow sequential loop — that's what timed out before. Two changes:
 *   1. Bounded concurrency (CONCURRENCY below) — several requests in flight
 *      at once instead of one-at-a-time-with-a-delay.
 *   2. Checkpointing to data/fandom-checkpoint.json after every batch. If
 *      the process is killed/times out partway through, re-running
 *      `npm run scrape` resumes from the last saved checkpoint instead of
 *      starting over from page 1.
 */

const API_BASE = "https://cardfight.fandom.com/api.php";
const CATEGORY = "Category:Cards";
const CONCURRENCY = 8; // simultaneous page fetches — raise/lower if you see rate-limit errors
const CHECKPOINT_PATH = path.join(__dirname, "..", "..", "data", "fandom-checkpoint.json");

class FandomAdapter extends CardSource {
  get id() {
    return "fandom";
  }

  async fetchAll() {
    const titles = await this.listCardPageTitles();
    console.log(`[fandom] found ${titles.length} card pages in ${CATEGORY}`);

    const checkpoint = loadCheckpoint();
    const alreadyDone = new Set(checkpoint.results.map((r) => r.number));
    const remaining = titles.filter((t) => !alreadyDone.has(t));
    console.log(`[fandom] ${alreadyDone.size} already fetched from a previous run, ${remaining.length} remaining`);

    const results = [...checkpoint.results];
    let completed = 0;

    for (let i = 0; i < remaining.length; i += CONCURRENCY) {
      const batch = remaining.slice(i, i + CONCURRENCY);
      const batchResults = await Promise.all(
        batch.map(async (title) => {
          try {
            return await this.fetchCardPage(title);
          } catch (err) {
            console.error(`[fandom] failed to parse "${title}": ${err.message}`);
            return null;
          }
        })
      );
      for (const r of batchResults) if (r) results.push(r);

      completed += batch.length;
      if (completed % (CONCURRENCY * 10) === 0 || completed === remaining.length) {
        console.log(`[fandom] progress: ${completed}/${remaining.length} (+ ${alreadyDone.size} from checkpoint)`);
        saveCheckpoint(results);
      }
    }

    saveCheckpoint(results); // final save
    return results;
  }

  /** Paginate through action=query&list=categorymembers until exhausted. */
  async listCardPageTitles() {
    const titles = [];
    let cmcontinue = null;

    do {
      const { data } = await axios.get(API_BASE, {
        params: {
          action: "query",
          list: "categorymembers",
          cmtitle: CATEGORY,
          cmlimit: 500,
          format: "json",
          ...(cmcontinue ? { cmcontinue } : {}),
        },
        headers: { "User-Agent": "Mozilla/5.0 (compatible; VanguardEngineBot/0.1)" },
        timeout: 15000,
      });

      const members = data?.query?.categorymembers ?? [];
      titles.push(...members.filter((m) => m.ns === 0).map((m) => m.title));
      cmcontinue = data?.continue?.cmcontinue ?? null;
    } while (cmcontinue);

    return titles;
  }

  /** Fetch one page's rendered card table and map it to a RawCard. */
  async fetchCardPage(title) {
    const { data } = await axios.get(API_BASE, {
      params: { action: "parse", page: title, format: "json", prop: "text" },
      headers: { "User-Agent": "Mozilla/5.0 (compatible; VanguardEngineBot/0.1)" },
      timeout: 15000,
    });

    const html = data?.parse?.text?.["*"];
    if (!html) return null;

    const $ = cheerio.load(html);
    const cftable = $(".cftable").first();
    if (cftable.length === 0) return null; // not actually a card page (e.g. a set/list page)

    const fields = {};
    cftable.find(".info-main table tr").each((_, row) => {
      const tds = $(row).find("td");
      if (tds.length < 2) return;
      const label = $(tds[0]).text().trim();
      // If a row has more than 2 cells (rare, e.g. a table-within-a-table),
      // join the rest as the value rather than dropping data.
      const value = tds
        .slice(1)
        .toArray()
        .map((td) => $(td).text().trim())
        .filter(Boolean)
        .join(" / ");
      if (label) fields[label] = value;
    });

    // Fallback: recover nation from the cftable's second CSS class if there
    // was no explicit "Nation" row (e.g. "cftable stoicheia" -> "stoicheia").
    const nationFromClass = (cftable.attr("class") || "").split(/\s+/)[1] || "";

    // "Grade / Skill" sometimes combined as e.g. "2 / Intercept"; handle both
    // a combined field and a plain "Grade" field.
    const [gradeRaw] = (fields["Grade / Skill"] || fields["Grade"] || "").split("/").map((s) => s?.trim());

    return {
      number: title, // page title stands in for id — see class doc in the original notes below
      name: fields["Name"] || title,
      clan: fields["Clan"] || "",
      nation: fields["Nation"] || capitalize(nationFromClass),
      grade: gradeRaw || fields["Grade"] || "",
      power: fields["Power"] || "",
      shield: fields["Shield"] || "",
      critical: fields["Critical"] || "",
      triggerType: fields["Trigger"] || "",
      cardType: fields["Card Type"] || fields["Type"] || "",
      skillText: fields["Card Effect(s)"] || fields["Card Effect"] || fields["Effect"] || "",
      setName: fields["Card Set(s)"] || "",
    };
  }
}

function loadCheckpoint() {
  try {
    const raw = fs.readFileSync(CHECKPOINT_PATH, "utf-8");
    return JSON.parse(raw);
  } catch {
    return { results: [] };
  }
}

function saveCheckpoint(results) {
  fs.mkdirSync(path.dirname(CHECKPOINT_PATH), { recursive: true });
  fs.writeFileSync(CHECKPOINT_PATH, JSON.stringify({ results }, null, 0));
}

function capitalize(s) {
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : "";
}

module.exports = FandomAdapter;
module.exports.CHECKPOINT_PATH = CHECKPOINT_PATH;
