const { chromium } = require("playwright");
const CardSource = require("./CardSource");

/**
 * OfficialSiteAdapter.js  (v2 — Playwright-based)
 *
 * CONFIRMED against the live site (2026-09-04):
 *   - The real domain is en.cf-vanguard.com (NOT cf-vanguard.com, which is
 *     the Japanese-only site).
 *   - https://en.cf-vanguard.com/cardlist/ renders only an empty search
 *     form in the raw HTML response. The actual card grid is injected by
 *     client-side JavaScript after the page loads (confirmed: a plain
 *     HTTP fetch of that URL returns no card data at all, just the form).
 *   - This means the v1 axios+cheerio approach cannot work here — cheerio
 *     never runs the page's JS, so it will always see an empty list.
 *
 * This version drives a real (headless) browser with Playwright, which
 * executes the page's JS like a normal visitor's browser would, then reads
 * the rendered DOM.
 *
 * STILL TO CONFIRM (could not be done from this sandbox — no network/browser
 * access here): the exact CSS selectors for each card's fields once
 * rendered. Run `npm run inspect -- "https://en.cf-vanguard.com/cardlist/"`
 * first — it now dumps the DOM *after* rendering — open the saved file,
 * search for one known card name, and fix SELECTORS below to match what
 * you find around it.
 */

const SELECTORS = {
  // TODO: confirm each of these against the rendered DOM (see note above).
  searchButton: 'button[type="submit"], .btn-search, .search-btn',
  cardItem: ".card-list-item, .cardlist-item, .card_list_item",
  fields: {
    number: ".card-number, .number",
    name: ".card-name, .name",
    clan: ".card-clan, .clan",
    nation: ".card-nation, .nation",
    grade: ".card-grade, .grade",
    power: ".card-power, .power",
    shield: ".card-shield, .shield",
    critical: ".card-critical, .critical",
    triggerType: ".card-trigger, .trigger",
    cardType: ".card-type, .unit-type",
    skillText: ".card-skill, .skill-text",
    setName: ".card-set, .product-name",
  },
  nextPageButton: ".pager-next, .pagination-next, a.next",
};

class OfficialSiteAdapter extends CardSource {
  get id() {
    return "official-en";
  }

  async fetchAll() {
    const browser = await chromium.launch({ headless: true });
    const page = await browser.newPage();
    const allCards = [];

    try {
      await page.goto("https://en.cf-vanguard.com/cardlist/", { waitUntil: "networkidle" });

      // If the search requires submitting the (empty) form once to show
      // "all cards", trigger that here. Leave commented until confirmed
      // whether it's needed:
      // await page.click(SELECTORS.searchButton);
      // await page.waitForSelector(SELECTORS.cardItem);

      let hasNextPage = true;
      while (hasNextPage) {
        await page.waitForSelector(SELECTORS.cardItem, { timeout: 15000 }).catch(() => {});
        const pageCards = await page.$$eval(
          SELECTORS.cardItem,
          (items, fieldSelectors) =>
            items.map((el) => {
              const text = (sel) => el.querySelector(sel)?.textContent?.trim() ?? "";
              return {
                number: text(fieldSelectors.number),
                name: text(fieldSelectors.name),
                clan: text(fieldSelectors.clan),
                nation: text(fieldSelectors.nation),
                grade: text(fieldSelectors.grade),
                power: text(fieldSelectors.power),
                shield: text(fieldSelectors.shield),
                critical: text(fieldSelectors.critical),
                triggerType: text(fieldSelectors.triggerType),
                cardType: text(fieldSelectors.cardType),
                skillText: text(fieldSelectors.skillText),
                setName: text(fieldSelectors.setName),
              };
            }),
          SELECTORS.fields
        );
        allCards.push(...pageCards);

        const nextBtn = await page.$(SELECTORS.nextPageButton);
        if (nextBtn) {
          await nextBtn.click();
          await page.waitForLoadState("networkidle");
        } else {
          hasNextPage = false;
        }
      }
    } finally {
      await browser.close();
    }

    return allCards;
  }
}

module.exports = OfficialSiteAdapter;
module.exports.SELECTORS = SELECTORS;
