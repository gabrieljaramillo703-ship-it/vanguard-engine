/**
 * inspect.js
 * Usage: node src/scraper/inspect.js "https://en.cf-vanguard.com/cardlist/"
 *
 * Confirmed the raw HTML response from en.cf-vanguard.com/cardlist/ has no
 * card data — it's added by client-side JS after load. This script uses a
 * real (headless) browser via Playwright so the JS actually runs, then saves
 * the rendered DOM to inspect_output.html so you can find the real class
 * names and update OfficialSiteAdapter.js's SELECTORS accordingly.
 *
 * First time setup: `npx playwright install chromium` (downloads the browser
 * binary — not something this sandbox could do without network access).
 */
const { chromium } = require("playwright");
const fs = require("fs");

async function main() {
  const url = process.argv[2];
  if (!url) {
    console.error('Usage: node src/scraper/inspect.js "<url>"');
    process.exit(1);
  }

  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  await page.goto(url, { waitUntil: "networkidle" });

  // Give any lazy-loaded search results a moment, in case "networkidle"
  // fires before the card grid actually populates.
  await page.waitForTimeout(2000);

  const html = await page.content();
  fs.writeFileSync("inspect_output.html", html);
  console.log(`Saved rendered DOM to inspect_output.html (${html.length} bytes).`);
  console.log('Open it and search for a known card name to find the real selectors.');

  await browser.close();
}

main().catch((err) => {
  console.error("Fetch failed:", err.message);
  process.exit(1);
});
