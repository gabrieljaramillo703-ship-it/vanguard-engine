/**
 * inspectFandomPage.js
 * Usage: node src/scraper/inspectFandomPage.js "Healing Magick, Aexlunus"
 *
 * Dumps EVERY raw label/value pair found in a Fandom card page's infobox —
 * not just the ones FandomAdapter.js currently maps. Use this when a card's
 * fields come out wrong/empty: it tells us the real label Fandom used (e.g.
 * maybe Order-type pages call it "Type" instead of "Card Type"), so
 * FandomAdapter.js's field mapping can be corrected to match reality
 * instead of guessing.
 */
const axios = require("axios");
const cheerio = require("cheerio");

const API_BASE = "https://cardfight.fandom.com/api.php";

async function main() {
  const title = process.argv[2];
  if (!title) {
    console.error('Usage: node src/scraper/inspectFandomPage.js "<page title>"');
    process.exit(1);
  }

  const { data } = await axios.get(API_BASE, {
    params: { action: "parse", page: title, format: "json", prop: "text" },
    headers: { "User-Agent": "Mozilla/5.0 (compatible; VanguardEngineBot/0.1)" },
    timeout: 15000,
  });

  const html = data?.parse?.text?.["*"];
  if (!html) {
    console.error("No page content returned. Full API response:", JSON.stringify(data, null, 2));
    return;
  }

  const $ = cheerio.load(html);
  const cftable = $(".cftable").first();
  if (cftable.length === 0) {
    console.error('No ".cftable" found on this page — dumping first 2000 chars of HTML instead:');
    console.log(html.slice(0, 2000));
    return;
  }

  console.log(`Raw table fields for "${title}" (cftable class="${cftable.attr("class")}"):\n`);
  cftable.find(".info-main table tr").each((_, row) => {
    const tds = $(row).find("td");
    if (tds.length < 2) return;
    const label = $(tds[0]).text().trim();
    const value = tds
      .slice(1)
      .toArray()
      .map((td) => $(td).text().trim())
      .join(" | ");
    console.log(`  "${label}" -> "${value}"`);
  });
}

main().catch((err) => {
  console.error("Fetch failed:", err.message);
  process.exit(1);
});
