const Card = require("../Card");

/**
 * Maps a RawCard (whatever shape an adapter scraped) into the Card shape
 * the engine consumes. Keeping this separate from the adapters means adding
 * a second source later (e.g. a fansite fallback for cards the official site
 * hasn't posted in English yet) never touches the engine or the adapters —
 * only this one mapping function needs a branch.
 */

const TRIGGER_MAP = {
  "critical trigger": "critical",
  "draw trigger": "draw",
  "front trigger": "front",
  "heal trigger": "heal",
  "over trigger": "over",
  over: "over",
};

function normalizeCard(raw) {
  const grade = parseIntSafe(raw.grade);
  const power = parseIntSafe(raw.power);
  const shield = parseIntSafe(raw.shield);
  const critical = parseIntSafe(raw.critical) || 1;
  const triggerType = TRIGGER_MAP[raw.triggerType?.toLowerCase().trim()] ?? null;
  const cardType = classifyCardType(raw.cardType);
  const isStrideUnit = detectStrideUnit(grade, raw.cardType);

  return new Card({
    id: raw.number,
    name: raw.name,
    grade,
    power,
    shield,
    critical,
    cardType,
    triggerType,
    clan: raw.clan || "Unknown",
    nation: raw.nation || "Unknown",
    skillText: raw.skillText || "",
    isStrideUnit,
  });
}

/**
 * Grade 4 is exclusive to Stride units in Standard format — no other card
 * type reaches Grade 4 — so grade alone is a reliable signal. Also checks
 * the raw "Card Type" text for an explicit "Stride"/"G Unit" mention as a
 * backup, in case a page's Grade field is missing/malformed but its type
 * text isn't (this was the exact kind of gap the incomplete-cards.json
 * pass exists to catch — see runWeeklyScrape.js).
 */
function detectStrideUnit(grade, rawCardType) {
  if (grade === 4) return true;
  return /stride|g[\s-]?unit/i.test(rawCardType || "");
}

/**
 * Maps the raw "Card Type" text (whatever an adapter scraped, e.g. "Normal
 * Unit", "Normal Order", "Critical Trigger") into one of the engine's three
 * card types: "unit" | "trigger" | "order".
 *
 * This matters because Engine.js only rides/calls/attacks with cardType
 * === "unit" — an Order wrongly classified as "unit" would show up as a
 * legal (but nonsensical, 0-power) rear-guard or ride target. Orders aren't
 * played through the ride/call/attack flow at all; they're a separate
 * main-phase action the engine doesn't automate yet (tracked as a gap, not
 * silently mis-modeled).
 */
function classifyCardType(rawCardType) {
  const text = (rawCardType || "").toLowerCase();
  if (/order/.test(text)) return "order";
  if (/trigger/.test(text)) return "trigger";
  return "unit";
}

function parseIntSafe(value) {
  const n = parseInt(String(value).replace(/[^\d-]/g, ""), 10);
  return Number.isNaN(n) ? 0 : n;
}

module.exports = { normalizeCard, TRIGGER_MAP, classifyCardType, detectStrideUnit };
