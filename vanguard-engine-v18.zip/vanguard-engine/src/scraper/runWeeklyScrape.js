const fs = require("fs");
const path = require("path");
const OfficialSiteAdapter = require("./OfficialSiteAdapter");
const FandomAdapter = require("./FandomAdapter");
const { normalizeCard } = require("./normalizeCard");

const OUTPUT_PATH = path.join(__dirname, "..", "..", "data", "cards.json");
const INCOMPLETE_PATH = path.join(__dirname, "..", "..", "data", "incomplete-cards.json");

// Order matters: the FIRST source to successfully return a given card id
// wins if the same id shows up again from a later source. Fandom is now
// primary — it's proven reliable (full catalog, structured infobox data via
// the MediaWiki API) — so it wins any conflict. Official site stays as a
// secondary pass, mainly to pick up brand-new weekly announcements that
// haven't been added to the wiki yet.
const SOURCES = [new FandomAdapter(), new OfficialSiteAdapter()];

async function runScrape() {
  const allNormalized = [];
  const seenIds = new Set();

  for (const source of SOURCES) {
    console.log(`[scraper] fetching from ${source.id}...`);
    let rawCards = [];
    try {
      rawCards = await source.fetchAll();
    } catch (err) {
      console.error(`[scraper] ${source.id} failed:`, err.message);
      continue;
    }
    console.log(`[scraper] ${source.id} returned ${rawCards.length} raw cards`);

    for (const raw of rawCards) {
      const card = normalizeCard(raw);
      if (!card.id || seenIds.has(card.id)) continue; // first source to see an id wins
      seenIds.add(card.id);
      allNormalized.push(card);
    }
  }

  // Data-quality pass: some Fandom pages are simply incomplete (confirmed
  // live — "Healing Magick, Aexlunus" is a real Normal Unit with no Power/
  // Shield rows on its page at all, not an Order). A "unit" with Power 0
  // is virtually always a missing-data page, not a real 0-power card, so
  // flag these separately instead of silently shipping them as if 0 were
  // their real printed stat — that would make them unplayable/broken once
  // used in an actual game.
  const incomplete = allNormalized.filter((c) => c.cardType === "unit" && c.power === 0);
  if (incomplete.length > 0) {
    fs.mkdirSync(path.dirname(INCOMPLETE_PATH), { recursive: true });
    fs.writeFileSync(INCOMPLETE_PATH, JSON.stringify(incomplete.map((c) => ({ id: c.id, name: c.name })), null, 2));
    console.log(
      `[scraper] WARNING: ${incomplete.length} unit cards have Power 0 (likely incomplete wiki pages, not real 0-power units). See ${INCOMPLETE_PATH}.`
    );
  }

  fs.mkdirSync(path.dirname(OUTPUT_PATH), { recursive: true });
  fs.writeFileSync(OUTPUT_PATH, JSON.stringify(allNormalized, null, 2));
  console.log(`[scraper] wrote ${allNormalized.length} cards to ${OUTPUT_PATH}`);
  return allNormalized;
}

// Allow running directly: node src/scraper/runWeeklyScrape.js
if (require.main === module) {
  runScrape().catch((err) => {
    console.error("[scraper] fatal error:", err);
    process.exit(1);
  });
}

module.exports = { runScrape, OUTPUT_PATH };
