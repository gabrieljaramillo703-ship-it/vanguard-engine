const cron = require("node-cron");
const { runScrape } = require("./runWeeklyScrape");

/**
 * Runs the scraper immediately, then on a weekly schedule.
 * Default: every Monday at 04:00 server time (after most weekly card
 * announcements/updates land). Adjust the cron expression as needed.
 *
 * Usage: node src/scraper/schedule.js
 * In production this would run as its own small service/process
 * (e.g. a background worker), separate from the web/game server.
 */
const CRON_EXPRESSION = "0 4 * * 1"; // min hour day-of-month month day-of-week (1 = Monday)

console.log(`[scheduler] running initial scrape...`);
runScrape().catch((err) => console.error("[scheduler] initial scrape failed:", err));

console.log(`[scheduler] scheduled weekly scrape: "${CRON_EXPRESSION}"`);
cron.schedule(CRON_EXPRESSION, () => {
  console.log(`[scheduler] weekly scrape triggered at ${new Date().toISOString()}`);
  runScrape().catch((err) => console.error("[scheduler] scheduled scrape failed:", err));
});
